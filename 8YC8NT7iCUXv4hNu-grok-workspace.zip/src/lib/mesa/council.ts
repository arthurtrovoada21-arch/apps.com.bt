import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { AGENT_BY_ID, AGENTS, DEFAULT_LOADOUT, knownAgentIds } from "@/lib/mesa/agents";
import { INTENT_LABEL, isIntent, type Artifact, type Intent, type MesaMessage, type ThreadSummary } from "@/lib/mesa/types";

type Sql = Awaited<ReturnType<(typeof import("@/lib/db"))["getSql"]>>;

async function db(): Promise<Sql> {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

function stamp(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value) return value;
  return new Date().toISOString();
}

function asIntent(value: unknown): Intent {
  return isIntent(value) ? value : "conversa";
}

function parseArtifact(value: unknown): Artifact | null {
  if (!value) return null;
  let raw: unknown = value;
  if (typeof value === "string") {
    try {
      raw = JSON.parse(value);
    } catch {
      return null;
    }
  }
  if (!raw || typeof raw !== "object") return null;
  const row = raw as Record<string, unknown>;
  const kind = row.kind;
  if (kind !== "html" && kind !== "code" && kind !== "markdown") return null;
  const content = typeof row.content === "string" ? row.content.slice(0, 20000) : "";
  if (!content.trim()) return null;
  const title = typeof row.title === "string" && row.title.trim() ? row.title.trim().slice(0, 80) : "Peça";
  const language =
    typeof row.language === "string" && row.language.trim()
      ? row.language.trim().slice(0, 24)
      : kind === "html"
        ? "html"
        : kind === "markdown"
          ? "markdown"
          : "text";
  return { kind, title, language, content };
}

function mapMessage(row: {
  id: string;
  role: string;
  agent_id: string | null;
  content: string;
  artifact: unknown;
}): MesaMessage {
  const role = row.role === "agent" || row.role === "synthesis" ? row.role : "user";
  return {
    id: row.id,
    role,
    agentId: row.agent_id,
    content: row.content,
    artifact: parseArtifact(row.artifact),
  };
}

function mapThread(row: { id: string; title: string; intent: string; updated_at: unknown }): ThreadSummary {
  return {
    id: row.id,
    title: row.title,
    intent: asIntent(row.intent),
    updatedAt: stamp(row.updated_at),
  };
}

async function readLoadout(sql: Sql, userId: string): Promise<string[]> {
  const rows = await sql<{ agent_id: string }>`
    select agent_id from loadouts where user_id = ${userId}
  `;
  const ids = knownAgentIds(rows.map((row) => row.agent_id));
  if (ids.length > 0) return ids;
  for (const id of DEFAULT_LOADOUT) {
    await sql`
      insert into loadouts (user_id, agent_id) values (${userId}, ${id})
      on conflict (user_id, agent_id) do nothing
    `;
  }
  return [...DEFAULT_LOADOUT];
}

export const listThreads = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const rows = await sql<{ id: string; title: string; intent: string; updated_at: unknown }>`
      select id, title, intent, updated_at
      from threads
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `;
    return rows.map(mapThread);
  });

export const getLoadout = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    return readLoadout(sql, context.userId);
  });

export const setLoadout = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { agentIds: string[] }) => {
    const ids = knownAgentIds(Array.isArray(input?.agentIds) ? input.agentIds : []);
    if (ids.length === 0) throw new Error("A mesa precisa de pelo menos uma voz.");
    return { agentIds: ids };
  })
  .handler(async ({ context, data }) => {
    const sql = await db();
    await sql`delete from loadouts where user_id = ${context.userId}`;
    for (const id of data.agentIds) {
      await sql`
        insert into loadouts (user_id, agent_id) values (${context.userId}, ${id})
        on conflict (user_id, agent_id) do nothing
      `;
    }
    return data.agentIds;
  });

export const getMessages = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { threadId: string }) => {
    const threadId = typeof input?.threadId === "string" ? input.threadId : "";
    if (!threadId) throw new Error("Conversa inválida.");
    return { threadId };
  })
  .handler(async ({ context, data }) => {
    const sql = await db();
    const owned = await sql<{ id: string }>`
      select id from threads where id = ${data.threadId} and user_id = ${context.userId}
    `;
    if (owned.length === 0) return { ok: false as const, error: "Conversa não encontrada." };
    const rows = await sql<{
      id: string;
      role: string;
      agent_id: string | null;
      content: string;
      artifact: unknown;
    }>`
      select id, role, agent_id, content, artifact
      from messages
      where thread_id = ${data.threadId} and user_id = ${context.userId}
      order by ord asc
    `;
    return { ok: true as const, messages: rows.map(mapMessage) };
  });

export const deleteThread = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { threadId: string }) => {
    const threadId = typeof input?.threadId === "string" ? input.threadId : "";
    if (!threadId) throw new Error("Conversa inválida.");
    return { threadId };
  })
  .handler(async ({ context, data }) => {
    const sql = await db();
    await sql`delete from threads where id = ${data.threadId} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

type SendInput = {
  threadId: string | null;
  text: string;
  intent: Intent;
  agentIds: string[];
};

export const sendToMesa = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: SendInput) => {
    const text = typeof input?.text === "string" ? input.text.trim() : "";
    if (!text) throw new Error("Escreva o pedido.");
    if (text.length > 4000) throw new Error("O pedido passa de 4000 caracteres.");
    const intent = isIntent(input?.intent) ? input.intent : "conversa";
    const agentIds = knownAgentIds(Array.isArray(input?.agentIds) ? input.agentIds : []);
    if (agentIds.length === 0) throw new Error("Escolha pelo menos uma voz.");
    const threadId = typeof input?.threadId === "string" && input.threadId ? input.threadId : null;
    return { threadId, text: text.slice(0, 4000), intent, agentIds };
  })
  .handler(async ({ context, data }) => {
    const sql = await db();
    const userId = context.userId;
    let threadId = data.threadId;
    let title = clipTitle(data.text);

    if (threadId) {
      const owned = await sql<{ id: string; title: string }>`
        select id, title from threads where id = ${threadId} and user_id = ${userId}
      `;
      if (owned.length === 0) return { ok: false as const, error: "Conversa não encontrada." };
      title = owned[0].title;
    } else {
      threadId = crypto.randomUUID();
      await sql`
        insert into threads (id, user_id, title, intent)
        values (${threadId}, ${userId}, ${title}, ${data.intent})
      `;
    }

    await sql`
      delete from loadouts where user_id = ${userId}
    `;
    for (const id of data.agentIds) {
      await sql`
        insert into loadouts (user_id, agent_id) values (${userId}, ${id})
        on conflict (user_id, agent_id) do nothing
      `;
    }

    const history = await sql<{ role: string; agent_id: string | null; content: string }>`
      select role, agent_id, content
      from messages
      where thread_id = ${threadId} and user_id = ${userId}
      order by ord desc
      limit 8
    `;
    const priorArtifact = await sql<{ artifact: unknown }>`
      select artifact from messages
      where thread_id = ${threadId} and user_id = ${userId} and artifact is not null
      order by ord desc
      limit 1
    `;

    const userMessageId = crypto.randomUUID();
    const baseOrd = await nextOrd(sql, threadId);
    await sql`
      insert into messages (id, thread_id, user_id, role, agent_id, content, artifact, ord)
      values (${userMessageId}, ${threadId}, ${userId}, ${"user"}, ${null}, ${data.text}, ${null}, ${baseOrd})
    `;

    const asked = await askCouncil({
      intent: data.intent,
      text: data.text,
      agentIds: data.agentIds,
      history: history.reverse(),
      priorArtifact: parseArtifact(priorArtifact[0]?.artifact),
    });

    if (!asked.ok) {
      await sql`delete from messages where id = ${userMessageId} and user_id = ${userId}`;
      if (!data.threadId) {
        await sql`delete from threads where id = ${threadId} and user_id = ${userId}`;
      }
      return { ok: false as const, error: asked.error };
    }

    const saved: MesaMessage[] = [
      { id: userMessageId, role: "user", agentId: null, content: data.text, artifact: null },
    ];

    let ord = baseOrd + 1;
    for (const turn of asked.turns) {
      const id = crypto.randomUUID();
      await sql`
        insert into messages (id, thread_id, user_id, role, agent_id, content, artifact, ord)
        values (${id}, ${threadId}, ${userId}, ${"agent"}, ${turn.agentId}, ${turn.text}, ${null}, ${ord})
      `;
      saved.push({ id, role: "agent", agentId: turn.agentId, content: turn.text, artifact: null });
      ord += 1;
    }

    const synthesisId = crypto.randomUUID();
    const artifactJson = asked.artifact ? JSON.stringify(asked.artifact) : null;
    await sql`
      insert into messages (id, thread_id, user_id, role, agent_id, content, artifact, ord)
      values (
        ${synthesisId},
        ${threadId},
        ${userId},
        ${"synthesis"},
        ${null},
        ${asked.synthesis},
        ${artifactJson},
        ${ord}
      )
    `;
    saved.push({
      id: synthesisId,
      role: "synthesis",
      agentId: null,
      content: asked.synthesis,
      artifact: asked.artifact,
    });

    const nextTitle = asked.title && history.length === 0 ? clipTitle(asked.title) : title;
    await sql`
      update threads
      set title = ${nextTitle}, intent = ${data.intent}, updated_at = now()
      where id = ${threadId} and user_id = ${userId}
    `;

    const threadRows = await sql<{ id: string; title: string; intent: string; updated_at: unknown }>`
      select id, title, intent, updated_at from threads where id = ${threadId} and user_id = ${userId}
    `;

    return {
      ok: true as const,
      thread: mapThread(threadRows[0]),
      messages: saved,
    };
  });

async function nextOrd(sql: Sql, threadId: string): Promise<number> {
  const rows = await sql<{ max: unknown }>`
    select max(ord) as max from messages where thread_id = ${threadId}
  `;
  const raw = rows[0]?.max;
  if (raw === null || raw === undefined || raw === "") return 0;
  const max = Number(raw);
  return Number.isFinite(max) ? max + 1 : 0;
}

function clipTitle(value: string): string {
  const clean = value.replace(/\s+/g, " ").trim();
  if (clean.length <= 56) return clean || "Nova conversa";
  return `${clean.slice(0, 55).trimEnd()}…`;
}

type Turn = { agentId: string; text: string };

async function askCouncil(input: {
  intent: Intent;
  text: string;
  agentIds: string[];
  history: { role: string; agent_id: string | null; content: string }[];
  priorArtifact: Artifact | null;
}): Promise<
  | { ok: true; title: string | null; turns: Turn[]; synthesis: string; artifact: Artifact | null }
  | { ok: false; error: string }
> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "A mesa não está disponível neste ambiente." };

  const roster = input.agentIds
    .map((id) => AGENT_BY_ID.get(id))
    .filter((agent): agent is NonNullable<typeof agent> => Boolean(agent))
    .map((agent) => `- ${agent.id} | ${agent.name} | ${agent.craft} | ${agent.voice}`)
    .join("\n");

  const historyText = input.history
    .map((row) => {
      const who =
        row.role === "user" ? "Pessoa" : row.role === "synthesis" ? "Decisão" : (AGENT_BY_ID.get(row.agent_id ?? "")?.name ?? "Voz");
      return `${who}: ${row.content.slice(0, 700)}`;
    })
    .join("\n");

  const prior = input.priorArtifact
    ? `Peça anterior (${input.priorArtifact.kind}, ${input.priorArtifact.title}):\n${input.priorArtifact.content.slice(0, 6000)}`
    : "Não há peça anterior.";

  const build =
    input.intent === "app" || input.intent === "site"
      ? "O artifact é obrigatório, kind html. Documento completo começando com <!DOCTYPE html>, CSS inline, sem imagens externas, sem scripts de terceiros. Visual editorial, sóbrio, fundo claro ou escuro coeso, tipografia de sistema, conteúdo real em português, bom no celular."
      : input.intent === "script"
        ? "O artifact é obrigatório, kind code. Script completo e executável, com comentário curto no topo dizendo como rodar."
        : input.intent === "texto" || input.intent === "plano"
          ? "O artifact é obrigatório, kind markdown. Entrega pronta, não um esboço de como seria."
          : "artifact pode ser null, a menos que a pessoa tenha pedido uma entrega concreta.";

  const system = `Você conduz a MESA, uma conversa entre vozes especialistas. Você é o Grok falando NO CARÁTER de cada voz sentada — não finja ter chamado outra API.
Responda só com um objeto JSON, sem cercas de markdown.
Formato:
{"title": string | null, "turns": [{"agentId": string, "text": string}], "synthesis": string, "artifact": null | {"kind": "html" | "code" | "markdown", "title": string, "language": string, "content": string}}
Regras:
- title: um título curto em português se esta for a primeira fala da pessoa; senão null.
- turns: 2 a 4 falas se houver vozes suficientes; 1 se só houver uma. Use apenas estes agentId. Elas se complementam ou discordam num ponto concreto. Cada text tem no máximo 500 caracteres, em português, no ofício da voz.
- synthesis: a decisão única, acionável, em português. Não recapitule quem falou.
- ${build}
- Não invente URLs. Não diga que gerou um arquivo fora do campo artifact.
- Se a pessoa pedir revisão, reescreva a peça anterior em vez de descrevê-la.
Vozes sentadas:
${roster}
Catálogo total da casa: ${AGENTS.length} vozes. Só falam as sentadas.`;

  const user = `Intenção: ${INTENT_LABEL[input.intent]}.
${prior}

Conversa até aqui:
${historyText || "(vazia)"}

Pedido agora:
${input.text}`;

  const messages = [
    { role: "system", content: system },
    { role: "user", content: user },
  ];

  let response = await complete(apiKey, messages, true);
  if (!response.ok && response.status === 400) {
    response = await complete(apiKey, messages, false);
  }
  if (!response.ok) {
    return { ok: false, error: "A mesa não respondeu. Tente de novo em instantes." };
  }

  const body = (await response.json()) as {
    choices?: { message?: { content?: unknown } }[];
  };
  const raw = textOf(body.choices?.[0]?.message?.content);
  if (!raw.trim()) return { ok: false, error: "A mesa voltou em silêncio. Tente de novo." };

  try {
    return normalizeCouncil(raw, input.agentIds);
  } catch {
    const fallback = input.agentIds[0] ?? "grok";
    return {
      ok: true,
      title: null,
      turns: [{ agentId: fallback, text: raw.slice(0, 900) }],
      synthesis: "A mesa respondeu fora do formato combinado. O texto acima é a fala bruta.",
      artifact: null,
    };
  }
}

function normalizeCouncil(raw: string, agentIds: string[]) {
  const parsed = extractJson(raw);
  const record = parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : {};
  const allowed = new Set(agentIds);
  const turns: Turn[] = [];
  if (Array.isArray(record.turns)) {
    for (const item of record.turns) {
      if (!item || typeof item !== "object") continue;
      const row = item as Record<string, unknown>;
      const agentId = typeof row.agentId === "string" ? row.agentId : "";
      const text = typeof row.text === "string" ? row.text.trim() : "";
      if (!allowed.has(agentId) || !text) continue;
      turns.push({ agentId, text: text.slice(0, 700) });
      if (turns.length >= 4) break;
    }
  }
  if (turns.length === 0) {
    turns.push({
      agentId: agentIds[0],
      text: "O pedido está na mesa. A decisão abaixo é o que seguimos.",
    });
  }
  const synthesisRaw = typeof record.synthesis === "string" ? record.synthesis.trim() : "";
  const synthesis = (synthesisRaw || turns.map((turn) => turn.text).join("\n\n")).slice(0, 4000);
  const title = typeof record.title === "string" && record.title.trim() ? record.title.trim().slice(0, 80) : null;
  return {
    ok: true as const,
    title,
    turns,
    synthesis,
    artifact: parseArtifact(record.artifact),
  };
}

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
    throw new Error("json");
  }
}

function textOf(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (part && typeof part === "object" && "text" in part) return String((part as { text: unknown }).text ?? "");
        return "";
      })
      .join("");
  }
  return "";
}

async function complete(
  apiKey: string,
  messages: { role: string; content: string }[],
  jsonMode: boolean,
): Promise<Response> {
  const body: Record<string, unknown> = {
    model: "grok-4.5",
    temperature: 0.5,
    max_tokens: 4500,
    messages,
  };
  if (jsonMode) body.response_format = { type: "json_object" };
  return fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(90_000),
  });
}
