import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, i as INTENT_LABEL, o as isIntent } from "./types-Bum9t72v.mjs";
import { i as knownAgentIds, n as AGENT_BY_ID, r as DEFAULT_LOADOUT, t as AGENTS } from "./agents-C2cE-DiL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/council-yMfftC2f.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function db() {
	const { getSql } = await import("./db-aDRTKPYN.mjs").then((n) => n.t).then((n) => n.t);
	return getSql();
}
function stamp(value) {
	if (value instanceof Date) return value.toISOString();
	if (typeof value === "string" && value) return value;
	return (/* @__PURE__ */ new Date()).toISOString();
}
function asIntent(value) {
	return isIntent(value) ? value : "conversa";
}
function parseArtifact(value) {
	if (!value) return null;
	let raw = value;
	if (typeof value === "string") try {
		raw = JSON.parse(value);
	} catch {
		return null;
	}
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	const kind = row.kind;
	if (kind !== "html" && kind !== "code" && kind !== "markdown") return null;
	const content = typeof row.content === "string" ? row.content.slice(0, 2e4) : "";
	if (!content.trim()) return null;
	return {
		kind,
		title: typeof row.title === "string" && row.title.trim() ? row.title.trim().slice(0, 80) : "Peça",
		language: typeof row.language === "string" && row.language.trim() ? row.language.trim().slice(0, 24) : kind === "html" ? "html" : kind === "markdown" ? "markdown" : "text",
		content
	};
}
function mapMessage(row) {
	const role = row.role === "agent" || row.role === "synthesis" ? row.role : "user";
	return {
		id: row.id,
		role,
		agentId: row.agent_id,
		content: row.content,
		artifact: parseArtifact(row.artifact)
	};
}
function mapThread(row) {
	return {
		id: row.id,
		title: row.title,
		intent: asIntent(row.intent),
		updatedAt: stamp(row.updated_at)
	};
}
async function readLoadout(sql, userId) {
	const rows = await sql`
    select agent_id from loadouts where user_id = ${userId}
  `;
	const ids = knownAgentIds(rows.map((row) => row.agent_id));
	if (ids.length > 0) return ids;
	for (const id of DEFAULT_LOADOUT) await sql`
      insert into loadouts (user_id, agent_id) values (${userId}, ${id})
      on conflict (user_id, agent_id) do nothing
    `;
	return [...DEFAULT_LOADOUT];
}
var listThreads_createServerFn_handler = createServerRpc({
	id: "53e1fd856b5333958b7fa08f13cdf3b20fd11d1b1f98b28eb335e5b187fa0f77",
	name: "listThreads",
	filename: "src/lib/mesa/council.ts"
}, (opts) => listThreads.__executeServer(opts));
var listThreads = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listThreads_createServerFn_handler, async ({ context }) => {
	return (await (await db())`
      select id, title, intent, updated_at
      from threads
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `).map(mapThread);
});
var getLoadout_createServerFn_handler = createServerRpc({
	id: "f3316d0ea0dc84c22412c9049e5a212e9607ad6271be7f6706c6e370ffc90b42",
	name: "getLoadout",
	filename: "src/lib/mesa/council.ts"
}, (opts) => getLoadout.__executeServer(opts));
var getLoadout = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getLoadout_createServerFn_handler, async ({ context }) => {
	return readLoadout(await db(), context.userId);
});
var setLoadout_createServerFn_handler = createServerRpc({
	id: "d4860edf814b113c6b1ed767554635b95882087a4d389ea8827db315070d7631",
	name: "setLoadout",
	filename: "src/lib/mesa/council.ts"
}, (opts) => setLoadout.__executeServer(opts));
var setLoadout = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const ids = knownAgentIds(Array.isArray(input?.agentIds) ? input.agentIds : []);
	if (ids.length === 0) throw new Error("A mesa precisa de pelo menos uma voz.");
	return { agentIds: ids };
}).handler(setLoadout_createServerFn_handler, async ({ context, data }) => {
	const sql = await db();
	await sql`delete from loadouts where user_id = ${context.userId}`;
	for (const id of data.agentIds) await sql`
        insert into loadouts (user_id, agent_id) values (${context.userId}, ${id})
        on conflict (user_id, agent_id) do nothing
      `;
	return data.agentIds;
});
var getMessages_createServerFn_handler = createServerRpc({
	id: "642740bc45d6b3e58ef783557a144457115203a91a4a3dc84ff9659dc8eec709",
	name: "getMessages",
	filename: "src/lib/mesa/council.ts"
}, (opts) => getMessages.__executeServer(opts));
var getMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const threadId = typeof input?.threadId === "string" ? input.threadId : "";
	if (!threadId) throw new Error("Conversa inválida.");
	return { threadId };
}).handler(getMessages_createServerFn_handler, async ({ context, data }) => {
	const sql = await db();
	if ((await sql`
      select id from threads where id = ${data.threadId} and user_id = ${context.userId}
    `).length === 0) return {
		ok: false,
		error: "Conversa não encontrada."
	};
	return {
		ok: true,
		messages: (await sql`
      select id, role, agent_id, content, artifact
      from messages
      where thread_id = ${data.threadId} and user_id = ${context.userId}
      order by ord asc
    `).map(mapMessage)
	};
});
var deleteThread_createServerFn_handler = createServerRpc({
	id: "16dd6a5a858b194673137c653d0cff1e934c9df233a7dda0f3ae126cb7c728b3",
	name: "deleteThread",
	filename: "src/lib/mesa/council.ts"
}, (opts) => deleteThread.__executeServer(opts));
var deleteThread = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const threadId = typeof input?.threadId === "string" ? input.threadId : "";
	if (!threadId) throw new Error("Conversa inválida.");
	return { threadId };
}).handler(deleteThread_createServerFn_handler, async ({ context, data }) => {
	await (await db())`delete from threads where id = ${data.threadId} and user_id = ${context.userId}`;
	return { ok: true };
});
var sendToMesa_createServerFn_handler = createServerRpc({
	id: "ef5b34ccedb82aba52080f65009eda8ea18026fb51ec0d1a38feaeef664d221b",
	name: "sendToMesa",
	filename: "src/lib/mesa/council.ts"
}, (opts) => sendToMesa.__executeServer(opts));
var sendToMesa = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const text = typeof input?.text === "string" ? input.text.trim() : "";
	if (!text) throw new Error("Escreva o pedido.");
	if (text.length > 4e3) throw new Error("O pedido passa de 4000 caracteres.");
	const intent = isIntent(input?.intent) ? input.intent : "conversa";
	const agentIds = knownAgentIds(Array.isArray(input?.agentIds) ? input.agentIds : []);
	if (agentIds.length === 0) throw new Error("Escolha pelo menos uma voz.");
	return {
		threadId: typeof input?.threadId === "string" && input.threadId ? input.threadId : null,
		text: text.slice(0, 4e3),
		intent,
		agentIds
	};
}).handler(sendToMesa_createServerFn_handler, async ({ context, data }) => {
	const sql = await db();
	const userId = context.userId;
	let threadId = data.threadId;
	let title = clipTitle(data.text);
	if (threadId) {
		const owned = await sql`
        select id, title from threads where id = ${threadId} and user_id = ${userId}
      `;
		if (owned.length === 0) return {
			ok: false,
			error: "Conversa não encontrada."
		};
		title = owned[0].title;
	} else {
		threadId = crypto.randomUUID();
		await sql`
        insert into threads (id, user_id, title, intent)
        values (${threadId}, ${userId}, ${title}, ${data.intent})
      `;
	}
	await sql`
      delete from loadouts where user_id = ${userId}
    `;
	for (const id of data.agentIds) await sql`
        insert into loadouts (user_id, agent_id) values (${userId}, ${id})
        on conflict (user_id, agent_id) do nothing
      `;
	const history = await sql`
      select role, agent_id, content
      from messages
      where thread_id = ${threadId} and user_id = ${userId}
      order by ord desc
      limit 8
    `;
	const priorArtifact = await sql`
      select artifact from messages
      where thread_id = ${threadId} and user_id = ${userId} and artifact is not null
      order by ord desc
      limit 1
    `;
	const userMessageId = crypto.randomUUID();
	const baseOrd = await nextOrd(sql, threadId);
	await sql`
      insert into messages (id, thread_id, user_id, role, agent_id, content, artifact, ord)
      values (${userMessageId}, ${threadId}, ${userId}, ${"user"}, ${null}, ${data.text}, ${null}, ${baseOrd})
    `;
	const asked = await askCouncil({
		intent: data.intent,
		text: data.text,
		agentIds: data.agentIds,
		history: history.reverse(),
		priorArtifact: parseArtifact(priorArtifact[0]?.artifact)
	});
	if (!asked.ok) {
		await sql`delete from messages where id = ${userMessageId} and user_id = ${userId}`;
		if (!data.threadId) await sql`delete from threads where id = ${threadId} and user_id = ${userId}`;
		return {
			ok: false,
			error: asked.error
		};
	}
	const saved = [{
		id: userMessageId,
		role: "user",
		agentId: null,
		content: data.text,
		artifact: null
	}];
	let ord = baseOrd + 1;
	for (const turn of asked.turns) {
		const id = crypto.randomUUID();
		await sql`
        insert into messages (id, thread_id, user_id, role, agent_id, content, artifact, ord)
        values (${id}, ${threadId}, ${userId}, ${"agent"}, ${turn.agentId}, ${turn.text}, ${null}, ${ord})
      `;
		saved.push({
			id,
			role: "agent",
			agentId: turn.agentId,
			content: turn.text,
			artifact: null
		});
		ord += 1;
	}
	const synthesisId = crypto.randomUUID();
	const artifactJson = asked.artifact ? JSON.stringify(asked.artifact) : null;
	await sql`
      insert into messages (id, thread_id, user_id, role, agent_id, content, artifact, ord)
      values (
        ${synthesisId},
        ${threadId},
        ${userId},
        ${"synthesis"},
        ${null},
        ${asked.synthesis},
        ${artifactJson},
        ${ord}
      )
    `;
	saved.push({
		id: synthesisId,
		role: "synthesis",
		agentId: null,
		content: asked.synthesis,
		artifact: asked.artifact
	});
	await sql`
      update threads
      set title = ${asked.title && history.length === 0 ? clipTitle(asked.title) : title}, intent = ${data.intent}, updated_at = now()
      where id = ${threadId} and user_id = ${userId}
    `;
	return {
		ok: true,
		thread: mapThread((await sql`
      select id, title, intent, updated_at from threads where id = ${threadId} and user_id = ${userId}
    `)[0]),
		messages: saved
	};
});
async function nextOrd(sql, threadId) {
	const raw = (await sql`
    select max(ord) as max from messages where thread_id = ${threadId}
  `)[0]?.max;
	if (raw === null || raw === void 0 || raw === "") return 0;
	const max = Number(raw);
	return Number.isFinite(max) ? max + 1 : 0;
}
function clipTitle(value) {
	const clean = value.replace(/\s+/g, " ").trim();
	if (clean.length <= 56) return clean || "Nova conversa";
	return `${clean.slice(0, 55).trimEnd()}…`;
}
async function askCouncil(input) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "A mesa não está disponível neste ambiente."
	};
	const roster = input.agentIds.map((id) => AGENT_BY_ID.get(id)).filter((agent) => Boolean(agent)).map((agent) => `- ${agent.id} | ${agent.name} | ${agent.craft} | ${agent.voice}`).join("\n");
	const historyText = input.history.map((row) => {
		return `${row.role === "user" ? "Pessoa" : row.role === "synthesis" ? "Decisão" : AGENT_BY_ID.get(row.agent_id ?? "")?.name ?? "Voz"}: ${row.content.slice(0, 700)}`;
	}).join("\n");
	const prior = input.priorArtifact ? `Peça anterior (${input.priorArtifact.kind}, ${input.priorArtifact.title}):\n${input.priorArtifact.content.slice(0, 6e3)}` : "Não há peça anterior.";
	const system = `Você conduz a MESA, uma conversa entre vozes especialistas. Você é o Grok falando NO CARÁTER de cada voz sentada — não finja ter chamado outra API.
Responda só com um objeto JSON, sem cercas de markdown.
Formato:
{"title": string | null, "turns": [{"agentId": string, "text": string}], "synthesis": string, "artifact": null | {"kind": "html" | "code" | "markdown", "title": string, "language": string, "content": string}}
Regras:
- title: um título curto em português se esta for a primeira fala da pessoa; senão null.
- turns: 2 a 4 falas se houver vozes suficientes; 1 se só houver uma. Use apenas estes agentId. Elas se complementam ou discordam num ponto concreto. Cada text tem no máximo 500 caracteres, em português, no ofício da voz.
- synthesis: a decisão única, acionável, em português. Não recapitule quem falou.
- ${input.intent === "app" || input.intent === "site" ? "O artifact é obrigatório, kind html. Documento completo começando com <!DOCTYPE html>, CSS inline, sem imagens externas, sem scripts de terceiros. Visual editorial, sóbrio, fundo claro ou escuro coeso, tipografia de sistema, conteúdo real em português, bom no celular." : input.intent === "script" ? "O artifact é obrigatório, kind code. Script completo e executável, com comentário curto no topo dizendo como rodar." : input.intent === "texto" || input.intent === "plano" ? "O artifact é obrigatório, kind markdown. Entrega pronta, não um esboço de como seria." : "artifact pode ser null, a menos que a pessoa tenha pedido uma entrega concreta."}
- Não invente URLs. Não diga que gerou um arquivo fora do campo artifact.
- Se a pessoa pedir revisão, reescreva a peça anterior em vez de descrevê-la.
Vozes sentadas:
${roster}
Catálogo total da casa: ${AGENTS.length} vozes. Só falam as sentadas.`;
	const user = `Intenção: ${INTENT_LABEL[input.intent]}.
${prior}

Conversa até aqui:
${historyText || "(vazia)"}

Pedido agora:
${input.text}`;
	const messages = [{
		role: "system",
		content: system
	}, {
		role: "user",
		content: user
	}];
	let response = await complete(apiKey, messages, true);
	if (!response.ok && response.status === 400) response = await complete(apiKey, messages, false);
	if (!response.ok) return {
		ok: false,
		error: "A mesa não respondeu. Tente de novo em instantes."
	};
	const raw = textOf((await response.json()).choices?.[0]?.message?.content);
	if (!raw.trim()) return {
		ok: false,
		error: "A mesa voltou em silêncio. Tente de novo."
	};
	try {
		return normalizeCouncil(raw, input.agentIds);
	} catch {
		return {
			ok: true,
			title: null,
			turns: [{
				agentId: input.agentIds[0] ?? "grok",
				text: raw.slice(0, 900)
			}],
			synthesis: "A mesa respondeu fora do formato combinado. O texto acima é a fala bruta.",
			artifact: null
		};
	}
}
function normalizeCouncil(raw, agentIds) {
	const parsed = extractJson(raw);
	const record = parsed && typeof parsed === "object" ? parsed : {};
	const allowed = new Set(agentIds);
	const turns = [];
	if (Array.isArray(record.turns)) for (const item of record.turns) {
		if (!item || typeof item !== "object") continue;
		const row = item;
		const agentId = typeof row.agentId === "string" ? row.agentId : "";
		const text = typeof row.text === "string" ? row.text.trim() : "";
		if (!allowed.has(agentId) || !text) continue;
		turns.push({
			agentId,
			text: text.slice(0, 700)
		});
		if (turns.length >= 4) break;
	}
	if (turns.length === 0) turns.push({
		agentId: agentIds[0],
		text: "O pedido está na mesa. A decisão abaixo é o que seguimos."
	});
	const synthesis = ((typeof record.synthesis === "string" ? record.synthesis.trim() : "") || turns.map((turn) => turn.text).join("\n\n")).slice(0, 4e3);
	return {
		ok: true,
		title: typeof record.title === "string" && record.title.trim() ? record.title.trim().slice(0, 80) : null,
		turns,
		synthesis,
		artifact: parseArtifact(record.artifact)
	};
}
function extractJson(text) {
	const trimmed = text.trim();
	try {
		return JSON.parse(trimmed);
	} catch {
		const start = trimmed.indexOf("{");
		const end = trimmed.lastIndexOf("}");
		if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
		throw new Error("json");
	}
}
function textOf(content) {
	if (typeof content === "string") return content;
	if (Array.isArray(content)) return content.map((part) => {
		if (typeof part === "string") return part;
		if (part && typeof part === "object" && "text" in part) return String(part.text ?? "");
		return "";
	}).join("");
	return "";
}
async function complete(apiKey, messages, jsonMode) {
	const body = {
		model: "grok-4.5",
		temperature: .5,
		max_tokens: 4500,
		messages
	};
	if (jsonMode) body.response_format = { type: "json_object" };
	return fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(body),
		signal: AbortSignal.timeout(9e4)
	});
}
//#endregion
export { deleteThread_createServerFn_handler, getLoadout_createServerFn_handler, getMessages_createServerFn_handler, listThreads_createServerFn_handler, sendToMesa_createServerFn_handler, setLoadout_createServerFn_handler };
