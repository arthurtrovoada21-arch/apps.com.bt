import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as signOut } from "./client-IWHfIGH2.mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, i as INTENT_LABEL, n as CRAFT_LABEL, o as isIntent, r as INTENTS, t as CRAFTS } from "./types-Bum9t72v.mjs";
import { i as knownAgentIds, n as AGENT_BY_ID, t as AGENTS } from "./agents-C2cE-DiL.mjs";
import { a as hasGateSessionMarker } from "./server-DxP5dDrl.mjs";
import { n as useCurrentUser, r as useCurrentUserState, t as BootScreen } from "./use-current-user-49SqSQe5.mjs";
import { a as Plus, i as Send, o as Menu, r as Trash2, s as Copy, t as X } from "../_libs/lucide-react.mjs";
import { n as formatDistanceToNow, t as ptBR } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-xTobHTnd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var listThreads = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("53e1fd856b5333958b7fa08f13cdf3b20fd11d1b1f98b28eb335e5b187fa0f77"));
var getLoadout = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("f3316d0ea0dc84c22412c9049e5a212e9607ad6271be7f6706c6e370ffc90b42"));
var setLoadout = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const ids = knownAgentIds(Array.isArray(input?.agentIds) ? input.agentIds : []);
	if (ids.length === 0) throw new Error("A mesa precisa de pelo menos uma voz.");
	return { agentIds: ids };
}).handler(createSsrRpc("d4860edf814b113c6b1ed767554635b95882087a4d389ea8827db315070d7631"));
var getMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const threadId = typeof input?.threadId === "string" ? input.threadId : "";
	if (!threadId) throw new Error("Conversa inválida.");
	return { threadId };
}).handler(createSsrRpc("642740bc45d6b3e58ef783557a144457115203a91a4a3dc84ff9659dc8eec709"));
var deleteThread = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const threadId = typeof input?.threadId === "string" ? input.threadId : "";
	if (!threadId) throw new Error("Conversa inválida.");
	return { threadId };
}).handler(createSsrRpc("16dd6a5a858b194673137c653d0cff1e934c9df233a7dda0f3ae126cb7c728b3"));
var sendToMesa = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const text = typeof input?.text === "string" ? input.text.trim() : "";
	if (!text) throw new Error("Escreva o pedido.");
	if (text.length > 4e3) throw new Error("O pedido passa de 4000 caracteres.");
	const intent = isIntent(input?.intent) ? input.intent : "conversa";
	const agentIds = knownAgentIds(Array.isArray(input?.agentIds) ? input.agentIds : []);
	if (agentIds.length === 0) throw new Error("Escolha pelo menos uma voz.");
	return {
		threadId: typeof input?.threadId === "string" && input.threadId ? input.threadId : null,
		text: text.slice(0, 4e3),
		intent,
		agentIds
	};
}).handler(createSsrRpc("ef5b34ccedb82aba52080f65009eda8ea18026fb51ec0d1a38feaeef664d221b"));
var STARTERS = [
	{
		intent: "site",
		label: "Site",
		text: "Um site de uma página para um ateliê de cerâmica em São Paulo. Nome: Barro Norte. Três peças, horário de visita e como encomendar."
	},
	{
		intent: "app",
		label: "App",
		text: "Um app de lista de mercado para celular: adicionar item, marcar como comprado e agrupar por seção."
	},
	{
		intent: "script",
		label: "Script",
		text: "Um script em Python que lê uma pasta de fotos e organiza cópias em subpastas por ano e mês, sem apagar os originais."
	},
	{
		intent: "plano",
		label: "Plano",
		text: "Um plano de 30 dias para abrir um café de bairro com 40 lugares, orçamento enxuto e uma identidade quieta."
	}
];
function Studio() {
	const [threads, setThreads] = (0, import_react.useState)([]);
	const [loadout, setLoadout$1] = (0, import_react.useState)([]);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [intent, setIntent] = (0, import_react.useState)("site");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [bootError, setBootError] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [right, setRight] = (0, import_react.useState)("arsenal");
	const [pinned, setPinned] = (0, import_react.useState)(null);
	const [loadingThread, setLoadingThread] = (0, import_react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(null);
	const gen = (0, import_react.useRef)(0);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		Promise.all([listThreads(), getLoadout()]).then(([nextThreads, nextLoadout]) => {
			if (cancelled) return;
			setThreads(nextThreads);
			setLoadout$1(nextLoadout);
			setReady(true);
		}).catch((err) => {
			if (cancelled) return;
			if ((err instanceof Error ? err.message : "") === "Unauthorized") {
				window.location.assign("/login");
				return;
			}
			setBootError("Não foi possível abrir a mesa.");
			setReady(true);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const latestArtifact = (0, import_react.useMemo)(() => {
		for (let i = messages.length - 1; i >= 0; i -= 1) {
			const artifact = messages[i]?.artifact;
			if (artifact) return artifact;
		}
		return null;
	}, [messages]);
	const artifact = pinned ?? latestArtifact;
	(0, import_react.useEffect)(() => {
		const node = scroller.current;
		if (!node) return;
		node.scrollTo({ top: node.scrollHeight });
	}, [
		messages,
		sending,
		activeId
	]);
	function newChat() {
		gen.current += 1;
		setActiveId(null);
		setMessages([]);
		setPinned(null);
		setError(null);
		setSheet(null);
		setLoadingThread(false);
	}
	async function openThread(id) {
		const token = ++gen.current;
		setActiveId(id);
		setPinned(null);
		setError(null);
		setSheet(null);
		setLoadingThread(true);
		setMessages([]);
		try {
			const result = await getMessages({ data: { threadId: id } });
			if (gen.current !== token) return;
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setMessages(result.messages);
			const thread = threads.find((item) => item.id === id);
			if (thread) setIntent(thread.intent);
		} catch (err) {
			if (gen.current !== token) return;
			setError(err instanceof Error ? err.message : "Não abriu a conversa.");
		} finally {
			if (gen.current === token) setLoadingThread(false);
		}
	}
	async function removeThread(id) {
		if (confirmDelete !== id) {
			setConfirmDelete(id);
			return;
		}
		setConfirmDelete(null);
		await deleteThread({ data: { threadId: id } });
		setThreads((prev) => prev.filter((thread) => thread.id !== id));
		if (activeId === id) newChat();
	}
	async function toggleAgent(id) {
		const has = loadout.includes(id);
		if (has && loadout.length === 1) {
			setNotice("A mesa precisa de pelo menos uma voz.");
			return;
		}
		if (!has && loadout.length >= 8) {
			setNotice("Oito vozes no máximo. Tire uma para sentar outra.");
			return;
		}
		const next = has ? loadout.filter((item) => item !== id) : [...loadout, id];
		const previous = loadout;
		setLoadout$1(next);
		setNotice(null);
		try {
			const saved = await setLoadout({ data: { agentIds: next } });
			setLoadout$1(saved);
		} catch {
			setLoadout$1(previous);
			setNotice("Não consegui guardar o time.");
		}
	}
	async function onSend() {
		const text = draft.trim();
		if (!text || sending) return;
		if (loadout.length === 0) {
			setError("Escolha pelo menos uma voz.");
			setSheet("arsenal");
			return;
		}
		const token = gen.current;
		const threadId = activeId;
		setSending(true);
		setError(null);
		try {
			const result = await sendToMesa({ data: {
				threadId,
				text,
				intent,
				agentIds: loadout
			} });
			if (gen.current !== token) return;
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setDraft("");
			setActiveId(result.thread.id);
			setThreads((prev) => [result.thread, ...prev.filter((thread) => thread.id !== result.thread.id)]);
			setMessages((prev) => threadId ? [...prev, ...result.messages] : result.messages);
			if ([...result.messages].reverse().find((message) => message.artifact)?.artifact ?? null) {
				setPinned(null);
				setRight("piece");
			}
		} catch (err) {
			if (gen.current !== token) return;
			if ((err instanceof Error ? err.message : "") === "Unauthorized") {
				window.location.assign("/login");
				return;
			}
			setError("A mesa não respondeu. O pedido continua aqui.");
		} finally {
			if (gen.current === token) setSending(false);
		}
	}
	const seated = loadout.map((id) => AGENT_BY_ID.get(id)?.name).filter(Boolean).join(", ");
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-dvh items-center justify-center bg-bg text-sm text-muted",
		"aria-busy": "true",
		children: "Abrindo a mesa…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-14 shrink-0 items-center gap-2 border-b border-line px-3 sm:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-sm text-fg xl:hidden",
						onClick: () => setSheet("threads"),
						"aria-label": "Conversas",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-lg font-medium tracking-tight",
						children: "MESA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "hidden h-11 items-center rounded-sm px-3 text-sm text-muted hover:text-fg sm:inline-flex",
						onClick: () => {
							setRight("arsenal");
							setSheet("arsenal");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: loadout.length
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1",
							children: "na mesa"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-sm text-fg sm:hidden",
						onClick: () => {
							setRight("arsenal");
							setSheet("arsenal");
						},
						"aria-label": "Arsenal",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm tabular-nums",
							children: loadout.length
						})
					}),
					artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-sm px-3 text-sm text-fg xl:hidden",
						onClick: () => setSheet("piece"),
						children: "Peça"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: newChat,
							className: "inline-flex h-11 items-center gap-1 rounded-sm bg-bone px-3 text-sm font-medium text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Nova"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-w-36 overflow-hidden sm:max-w-56",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
						})]
					})
				]
			}),
			bootError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "border-b border-line px-4 py-3 text-sm text-danger",
				children: bootError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "hidden w-64 shrink-0 flex-col border-r border-line xl:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadList, {
							threads,
							activeId,
							confirmDelete,
							onOpen: (id) => void openThread(id),
							onDelete: (id) => void removeThread(id)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-w-0 flex-1 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: scroller,
							className: "min-h-0 flex-1 overflow-y-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 py-8",
								children: [
									messages.length === 0 && !loadingThread ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
										seated,
										onPick: (nextIntent, text) => {
											setIntent(nextIntent);
											setDraft(text);
										}
									}) : null,
									loadingThread ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Abrindo a conversa…"
									}) : null,
									messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBlock, {
										message,
										onOpenPiece: (next) => {
											setPinned(next);
											setRight("piece");
											setSheet("piece");
										}
									}, message.id)),
									sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "shimmer text-sm",
										children: [
											seated.split(", ").slice(0, 3).join(", "),
											" ",
											loadout.length > 3 ? "e o resto da mesa" : "",
											" estão conversando."
										]
									}) : null
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {
							draft,
							intent,
							sending,
							error,
							onDraft: setDraft,
							onIntent: setIntent,
							onSend: () => void onSend()
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "hidden w-96 shrink-0 flex-col border-l border-line xl:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RightPanel, {
							tab: right,
							onTab: setRight,
							loadout,
							notice,
							artifact,
							onToggle: (id) => void toggleAgent(id)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSheet, {
				open: sheet === "threads",
				title: "Conversas",
				onClose: () => setSheet(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadList, {
					threads,
					activeId,
					confirmDelete,
					onOpen: (id) => void openThread(id),
					onDelete: (id) => void removeThread(id)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSheet, {
				open: sheet === "arsenal",
				title: "Arsenal",
				onClose: () => setSheet(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arsenal, {
					loadout,
					notice,
					onToggle: (id) => void toggleAgent(id)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSheet, {
				open: sheet === "piece",
				title: artifact?.title ?? "Peça",
				onClose: () => setSheet(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArtifactView, { artifact })
			})
		]
	});
}
function EmptyState({ seated, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl font-medium sm:text-4xl",
				children: "O que a mesa constrói?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 max-w-lg text-sm leading-normal text-muted",
				children: [
					"Na mesa agora: ",
					seated || "ninguém",
					". Até oito vozes por pedido. O Grok conduz, no caráter de quem você sentou."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-3 sm:grid-cols-2",
				children: STARTERS.map((starter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPick(starter.intent, starter.text),
					className: "rounded-xl border border-line bg-elevated p-4 text-left transition-colors duration-150 hover:bg-subtle",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium tracking-wide text-faint",
						children: starter.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-sm leading-normal text-fg",
						children: starter.text
					})]
				}, starter.label))
			})
		]
	});
}
function MessageBlock({ message, onOpenPiece }) {
	if (message.role === "user") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rise flex justify-end",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-[85%] rounded-lg bg-bone px-4 py-3 text-sm leading-normal text-ink",
			children: message.content
		})
	});
	if (message.role === "synthesis") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rise rounded-xl border border-line bg-elevated p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: "Decisão da mesa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-normal whitespace-pre-wrap",
				children: message.content
			}),
			message.artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					if (message.artifact) onOpenPiece(message.artifact);
				},
				className: "mt-4 h-11 rounded-sm border border-line px-3 text-sm font-medium",
				children: ["Abrir peça · ", message.artifact.title]
			}) : null
		]
	});
	const agent = message.agentId ? AGENT_BY_ID.get(message.agentId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rise flex gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-8 shrink-0 place-items-center rounded-sm bg-subtle text-xs font-medium",
			children: agent?.mark ?? "MS"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-1 flex items-baseline gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: agent?.name ?? "Mesa"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-faint",
					children: agent ? CRAFT_LABEL[agent.craft] : ""
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-normal whitespace-pre-wrap",
				children: message.content
			})]
		})]
	});
}
function Composer({ draft, intent, sending, error, onDraft, onIntent, onSend }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "shrink-0 border-t border-line px-3 py-3 sm:px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-2xl",
			children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mb-2 text-sm text-danger",
				children: error
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-elevated p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-3",
						children: INTENTS.map((item) => {
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onIntent(item),
								className: item === intent ? "h-11 shrink-0 rounded-sm bg-bone px-3 text-sm font-medium text-ink" : "h-11 shrink-0 rounded-sm border border-line px-3 text-sm text-muted",
								children: INTENT_LABEL[item]
							}, item);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: draft,
						onChange: (event) => onDraft(event.target.value),
						onKeyDown: (event) => {
							if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
								event.preventDefault();
								onSend();
							}
						},
						rows: 3,
						maxLength: 4e3,
						placeholder: "Peça um app, um site, um script, um texto…",
						className: "w-full resize-none rounded-sm bg-transparent text-sm leading-normal text-fg placeholder:text-faint"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: "Ctrl + Enter envia"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onSend,
							disabled: sending || draft.trim().length === 0,
							className: "inline-flex h-11 items-center gap-2 rounded-sm bg-bone px-4 text-sm font-medium text-ink disabled:cursor-wait disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), sending ? "Em conversa" : "Pedir"]
						})]
					})
				]
			})]
		})
	});
}
function ThreadList({ threads, activeId, confirmDelete, onOpen, onDelete }) {
	if (threads.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-6 text-sm text-muted",
		children: "Nenhuma conversa ainda."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "min-h-0 flex-1 overflow-y-auto",
		children: threads.map((thread) => {
			const active = thread.id === activeId;
			const when = safeWhen(thread.updatedAt);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: active ? "bg-subtle" : void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-1 px-2 py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(thread.id),
						className: "min-h-11 min-w-0 flex-1 px-2 py-2 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium",
							children: thread.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block text-xs text-faint",
							children: [INTENT_LABEL[thread.intent], when ? ` · ${when}` : ""]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onDelete(thread.id),
						className: "mt-2 grid size-11 shrink-0 place-items-center rounded-sm text-faint hover:text-fg",
						"aria-label": confirmDelete === thread.id ? "Confirmar apagar" : "Apagar conversa",
						children: confirmDelete === thread.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-danger",
							children: "Sim"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				})
			}, thread.id);
		})
	});
}
function safeWhen(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return "";
	return formatDistanceToNow(date, {
		addSuffix: true,
		locale: ptBR
	});
}
function RightPanel({ tab, onTab, loadout, notice, artifact, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 border-b border-line p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
				selected: tab === "arsenal",
				onClick: () => onTab("arsenal"),
				children: "Arsenal"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
				selected: tab === "piece",
				onClick: () => onTab("piece"),
				children: "Peça"
			})]
		}), tab === "arsenal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arsenal, {
			loadout,
			notice,
			onToggle
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArtifactView, { artifact })]
	});
}
function TabButton({ selected, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: selected ? "h-11 flex-1 rounded-sm bg-bone text-sm font-medium text-ink" : "h-11 flex-1 rounded-sm border border-line text-sm text-muted",
		children
	});
}
function Arsenal({ loadout, notice, onToggle }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [craft, setCraft] = (0, import_react.useState)("todas");
	const needle = query.trim().toLowerCase();
	const visible = AGENTS.filter((agent) => {
		if (craft !== "todas" && agent.craft !== craft) return false;
		if (!needle) return true;
		return `${agent.name} ${agent.line}`.toLowerCase().includes(needle);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 border-b border-line px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm leading-normal text-muted",
					children: [
						AGENTS.length,
						" vozes. Até ",
						8,
						" sentam. O Grok conduz no caráter de quem você escolhe — não há conta separada de cada uma."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-faint tabular-nums",
					children: [
						loadout.length,
						" de ",
						8,
						" na mesa"
					]
				}),
				notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: notice
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Buscar voz",
					className: "h-11 w-full rounded-sm border border-line bg-bg px-3 text-sm placeholder:text-faint"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 overflow-x-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						selected: craft === "todas",
						onClick: () => setCraft("todas"),
						children: "Todas"
					}), CRAFTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						selected: craft === item,
						onClick: () => setCraft(item),
						children: CRAFT_LABEL[item]
					}, item))]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "min-h-0 flex-1 overflow-y-auto",
			children: visible.map((agent) => {
				const on = loadout.includes(agent.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onToggle(agent.id),
						className: "flex min-h-11 w-full items-center gap-3 px-4 py-3 text-left",
						"aria-pressed": on,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-8 shrink-0 place-items-center rounded-sm bg-subtle text-xs font-medium",
								children: agent.mark
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-medium",
									children: agent.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate text-xs text-faint",
									children: [
										CRAFT_LABEL[agent.craft],
										" · ",
										agent.line
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: on ? "text-xs font-medium text-fg" : "text-xs text-faint",
								children: on ? "Na mesa" : "Sentar"
							})
						]
					})
				}, agent.id);
			})
		})]
	});
}
function FilterChip({ selected, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: selected ? "h-11 shrink-0 rounded-sm bg-subtle px-3 text-sm text-fg" : "h-11 shrink-0 rounded-sm px-3 text-sm text-faint",
		children
	});
}
function ArtifactView({ artifact }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [frame, setFrame] = (0, import_react.useState)("full");
	if (!artifact) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-2xl font-medium",
			children: "Ainda sem peça"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-normal text-muted",
			children: "Peça um site, um app ou um script. A entrega aparece aqui, com prévia quando for uma página."
		})]
	});
	async function copy() {
		try {
			await navigator.clipboard.writeText(artifact?.content ?? "");
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	}
	function download() {
		const blob = new Blob([artifact?.content ?? ""], { type: "text/plain;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		const ext = artifact?.kind === "html" ? "html" : artifact?.kind === "markdown" ? "md" : "txt";
		link.href = url;
		link.download = `${slug(artifact?.title ?? "peca")}.${ext}`;
		link.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 border-b border-line px-3 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 flex-1 truncate text-sm font-medium",
					children: artifact.title
				}),
				copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "Copiado"
				}) : null,
				artifact.kind === "html" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFrame((current) => current === "full" ? "phone" : "full"),
					className: "h-11 rounded-sm px-2 text-xs text-muted",
					children: frame === "full" ? "Celular" : "Largo"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void copy(),
					className: "grid size-11 place-items-center rounded-sm",
					"aria-label": copied ? "Copiado" : "Copiar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: download,
					className: "h-11 rounded-sm px-2 text-xs text-muted",
					children: "Baixar"
				})
			]
		}), artifact.kind === "html" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: frame === "phone" ? "mx-auto min-h-0 w-full max-w-sm flex-1 p-3" : "min-h-0 flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				title: artifact.title,
				sandbox: "allow-scripts",
				srcDoc: artifact.content,
				className: "h-full min-h-80 w-full bg-bone"
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "min-h-0 flex-1 overflow-auto px-4 py-4 font-mono text-xs leading-normal whitespace-pre-wrap text-fg",
			children: artifact.content
		})]
	});
}
function slug(value) {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "peca";
}
function MobileSheet({ open, title, onClose, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-30 flex flex-col bg-bg xl:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex h-14 shrink-0 items-center gap-2 border-b border-line px-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "grid size-11 place-items-center rounded-sm",
				"aria-label": "Fechar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "truncate text-sm font-medium",
				children: title
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-0 flex-1 flex-col overflow-hidden",
			children
		})]
	});
}
function Home() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/login" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
