export const INTENTS = ["conversa", "app", "site", "script", "texto", "plano"] as const;

export type Intent = (typeof INTENTS)[number];

export const INTENT_LABEL: Record<Intent, string> = {
  conversa: "Conversa",
  app: "App",
  site: "Site",
  script: "Script",
  texto: "Texto",
  plano: "Plano",
};

export const CRAFTS = [
  "conversa",
  "codigo",
  "design",
  "produto",
  "pesquisa",
  "midia",
  "escrita",
] as const;

export type Craft = (typeof CRAFTS)[number];

export const CRAFT_LABEL: Record<Craft, string> = {
  conversa: "Conversa",
  codigo: "Código",
  design: "Design",
  produto: "Produto",
  pesquisa: "Pesquisa",
  midia: "Mídia",
  escrita: "Escrita",
};

export type Artifact = {
  kind: "html" | "code" | "markdown";
  title: string;
  language: string;
  content: string;
};

export type MesaMessage = {
  id: string;
  role: "user" | "agent" | "synthesis";
  agentId: string | null;
  content: string;
  artifact: Artifact | null;
};

export type ThreadSummary = {
  id: string;
  title: string;
  intent: Intent;
  updatedAt: string;
};

export function isIntent(value: unknown): value is Intent {
  return typeof value === "string" && (INTENTS as readonly string[]).includes(value);
}
