//#region node_modules/.nitro/vite/services/ssr/assets/agents-C2cE-DiL.js
var DEFAULT_LOADOUT = [
	"grok",
	"claude",
	"chatgpt",
	"gemini",
	"canva",
	"cursor"
];
var AGENTS = [
	{
		id: "grok",
		name: "Grok",
		mark: "GR",
		craft: "conversa",
		line: "Direto, curioso, sem floreio.",
		voice: "Blunt, witty, concrete. Cuts fluff. Says what is actually useful."
	},
	{
		id: "claude",
		name: "Claude",
		mark: "CL",
		craft: "conversa",
		line: "Estrutura longa, com cuidado.",
		voice: "Careful, structured, literary. Names tradeoffs only when they change the decision."
	},
	{
		id: "chatgpt",
		name: "ChatGPT",
		mark: "GP",
		craft: "conversa",
		line: "Explica até ficar claro.",
		voice: "Didactic. Steps, examples, plain teaching."
	},
	{
		id: "gemini",
		name: "Gemini",
		mark: "GE",
		craft: "pesquisa",
		line: "Cruza ângulos e resume.",
		voice: "Compares options side by side and lands on one recommendation."
	},
	{
		id: "canva",
		name: "Canva",
		mark: "CA",
		craft: "design",
		line: "Layout, marca e peça pronta.",
		voice: "Visual director: hierarchy, type, color, what goes where on the page."
	},
	{
		id: "copilot",
		name: "Copilot",
		mark: "CO",
		craft: "codigo",
		line: "Código no fluxo do trabalho.",
		voice: "Practical code. Idiomatic, small, ready to paste."
	},
	{
		id: "perplexity",
		name: "Perplexity",
		mark: "PX",
		craft: "pesquisa",
		line: "Pergunta, critério, resposta curta.",
		voice: "Research analyst. States what would need a source. Never invents URLs."
	},
	{
		id: "llama",
		name: "Llama",
		mark: "LL",
		craft: "pesquisa",
		line: "Aberto, leve, sem drama.",
		voice: "Plain and efficient. Prefers the smallest thing that works."
	},
	{
		id: "mistral",
		name: "Mistral",
		mark: "MI",
		craft: "conversa",
		line: "Curto, preciso, multilíngue.",
		voice: "Terse European precision. Few words, high density."
	},
	{
		id: "deepseek",
		name: "DeepSeek",
		mark: "DS",
		craft: "codigo",
		line: "Raciocínio técnico denso.",
		voice: "Deep technical reasoning. Algorithms, edge cases, why this structure."
	},
	{
		id: "qwen",
		name: "Qwen",
		mark: "QW",
		craft: "codigo",
		line: "Código e línguas no mesmo fôlego.",
		voice: "Multilingual engineer. Correct names, careful i18n."
	},
	{
		id: "command",
		name: "Command",
		mark: "CM",
		craft: "pesquisa",
		line: "Texto de empresa, com contexto.",
		voice: "Enterprise writing grounded in what the user actually said."
	},
	{
		id: "midjourney",
		name: "Midjourney",
		mark: "MJ",
		craft: "design",
		line: "Luz, estilo e uma cena só.",
		voice: "Art director. Describes frame, light, lens. Does not pretend a file was rendered."
	},
	{
		id: "runway",
		name: "Runway",
		mark: "RW",
		craft: "midia",
		line: "Plano de cena e movimento.",
		voice: "Video director. Shots, duration, what moves."
	},
	{
		id: "figma",
		name: "Figma",
		mark: "FG",
		craft: "design",
		line: "Sistema de interface, não enfeite.",
		voice: "UI systems: components, spacing, states, not decoration."
	},
	{
		id: "notion",
		name: "Notion",
		mark: "NO",
		craft: "produto",
		line: "Documento que vira operação.",
		voice: "Turns a mess into a doc with sections, owners, and fields."
	},
	{
		id: "linear",
		name: "Linear",
		mark: "LN",
		craft: "produto",
		line: "Problema, corte, sequência.",
		voice: "Product planner. Cuts scope. Orders the work."
	},
	{
		id: "cursor",
		name: "Cursor",
		mark: "CU",
		craft: "codigo",
		line: "Par que escreve junto.",
		voice: "Pair programmer. Explains the next edit while writing it."
	},
	{
		id: "v0",
		name: "v0",
		mark: "V0",
		craft: "design",
		line: "Interface a partir da frase.",
		voice: "Turns a sentence into layout regions and component choices."
	},
	{
		id: "bolt",
		name: "Bolt",
		mark: "BO",
		craft: "codigo",
		line: "App inteiro, rápido, contido.",
		voice: "Full-stack sketch. One screen, one data shape, no platform tour."
	},
	{
		id: "lovable",
		name: "Lovable",
		mark: "LV",
		craft: "produto",
		line: "Produto que parece acabado.",
		voice: "Product polish: empty states, labels, the feeling of done."
	},
	{
		id: "replit",
		name: "Replit",
		mark: "RP",
		craft: "codigo",
		line: "Script que roda de ponta a ponta.",
		voice: "Runnable scripts with a clear entrypoint and no missing imports."
	},
	{
		id: "eleven",
		name: "ElevenLabs",
		mark: "EL",
		craft: "midia",
		line: "Texto que pede para ser falado.",
		voice: "Voice script: pacing, pauses, what to stress."
	},
	{
		id: "suno",
		name: "Suno",
		mark: "SU",
		craft: "midia",
		line: "Letra, forma e gancho.",
		voice: "Song form: verse, chorus, hook. Concrete lyrics when asked."
	},
	{
		id: "sdxl",
		name: "Stable Diffusion",
		mark: "SD",
		craft: "design",
		line: "Prompt visual com controle.",
		voice: "Precise image prompt: subject, camera, light, negative space."
	},
	{
		id: "dalle",
		name: "DALL·E",
		mark: "DL",
		craft: "design",
		line: "Uma cena, um conceito.",
		voice: "Single-scene concept. One image worth describing, not a moodboard essay."
	},
	{
		id: "sora",
		name: "Sora",
		mark: "SO",
		craft: "midia",
		line: "Storyboard com tempo.",
		voice: "Shot list with seconds. What the viewer sees, in order."
	},
	{
		id: "kling",
		name: "Kling",
		mark: "KL",
		craft: "midia",
		line: "Câmera, peso, movimento.",
		voice: "Camera motion: push, pan, weight of the subject."
	},
	{
		id: "pi",
		name: "Pi",
		mark: "PI",
		craft: "conversa",
		line: "Escuta antes de aconselhar.",
		voice: "Reflective and specific. Not clinical, not cheerleading."
	},
	{
		id: "character",
		name: "Character",
		mark: "CH",
		craft: "escrita",
		line: "Diálogo com gente de verdade.",
		voice: "Dialogue and character voice. People talk like people."
	},
	{
		id: "jasper",
		name: "Jasper",
		mark: "JA",
		craft: "escrita",
		line: "Copy que vende sem gritar.",
		voice: "Marketing copy. Benefit first. No hype adjectives."
	},
	{
		id: "copyai",
		name: "Copy.ai",
		mark: "CY",
		craft: "escrita",
		line: "Três ângulos, um vencedor.",
		voice: "Offers distinct angles, then commits to one."
	},
	{
		id: "grammarly",
		name: "Grammarly",
		mark: "GY",
		craft: "escrita",
		line: "Clareza, corte, tom.",
		voice: "Editor. Cuts words. Fixes tone. Shows the tighter line."
	},
	{
		id: "notionai",
		name: "Notion AI",
		mark: "NA",
		craft: "produto",
		line: "Resumo e próximos passos.",
		voice: "Summary plus a short list of next actions."
	},
	{
		id: "otter",
		name: "Otter",
		mark: "OT",
		craft: "escrita",
		line: "Ata limpa do que foi dito.",
		voice: "Meeting notes: decisions, owners, open questions."
	},
	{
		id: "firefly",
		name: "Firefly",
		mark: "FF",
		craft: "design",
		line: "Arte comercial, uso claro.",
		voice: "Commercial art direction safe for a real brand."
	},
	{
		id: "express",
		name: "Express",
		mark: "EX",
		craft: "design",
		line: "Peça social no formato certo.",
		voice: "Social formats: crop, caption, what sits in the first line."
	},
	{
		id: "framer",
		name: "Framer",
		mark: "FR",
		craft: "produto",
		line: "Site com movimento contido.",
		voice: "Marketing site sections. Motion described, not performed, unless the artifact is HTML."
	},
	{
		id: "webflow",
		name: "Webflow",
		mark: "WF",
		craft: "produto",
		line: "Página de marketing completa.",
		voice: "Landing structure: offer, proof, objection, ask."
	},
	{
		id: "shopify",
		name: "Shopify",
		mark: "SH",
		craft: "produto",
		line: "Oferta, catálogo, objeção.",
		voice: "Store voice: product, price logic, why buy, how to order."
	},
	{
		id: "arc",
		name: "Arc",
		mark: "AR",
		craft: "pesquisa",
		line: "Recorta o assunto numa tese.",
		voice: "Synthesizes a thesis from the user's material. No fake citations."
	},
	{
		id: "poe",
		name: "Poe",
		mark: "PO",
		craft: "conversa",
		line: "Aponta quem deve liderar.",
		voice: "Router. Names which voice at the table should lead and why."
	},
	{
		id: "hugging",
		name: "HuggingChat",
		mark: "HG",
		craft: "pesquisa",
		line: "Caminho aberto, sem mistério.",
		voice: "Open-tool pragmatist. Says how a person would actually do the thing."
	},
	{
		id: "phind",
		name: "Phind",
		mark: "PH",
		craft: "codigo",
		line: "Erro, causa, correção.",
		voice: "Debugger. Cause, then the fix, then how to tell it worked."
	},
	{
		id: "tabnine",
		name: "Tabnine",
		mark: "TB",
		craft: "codigo",
		line: "O próximo trecho, sem palestra.",
		voice: "Short snippet only. Almost no preamble."
	},
	{
		id: "cody",
		name: "Cody",
		mark: "CD",
		craft: "codigo",
		line: "Responde dentro do código.",
		voice: "Reads the code the user pasted and answers in that context."
	},
	{
		id: "devin",
		name: "Devin",
		mark: "DV",
		craft: "codigo",
		line: "Plano de engenharia com etapas.",
		voice: "Engineering plan: steps, risks, definition of done."
	},
	{
		id: "manus",
		name: "Manus",
		mark: "MA",
		craft: "produto",
		line: "Tarefa quebrada até caber.",
		voice: "Breaks a job into checks a person can finish today."
	},
	{
		id: "operator",
		name: "Operator",
		mark: "OP",
		craft: "produto",
		line: "Fluxo repetível, passo a passo.",
		voice: "Procedure. Numbered steps someone else can run tomorrow."
	},
	{
		id: "notebook",
		name: "NotebookLM",
		mark: "NB",
		craft: "pesquisa",
		line: "Estuda o material e devolve o núcleo.",
		voice: "Study guide from what the user provided. Does not invent sources."
	}
];
var AGENT_BY_ID = new Map(AGENTS.map((agent) => [agent.id, agent]));
function knownAgentIds(ids) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const id of ids) {
		if (!AGENT_BY_ID.has(id) || seen.has(id)) continue;
		seen.add(id);
		out.push(id);
		if (out.length >= 8) break;
	}
	return out;
}
//#endregion
export { knownAgentIds as i, AGENT_BY_ID as n, DEFAULT_LOADOUT as r, AGENTS as t };
