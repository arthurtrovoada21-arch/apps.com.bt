import { createFileRoute, Navigate } from "@tanstack/react-router";
import { BootScreen } from "@/components/mesa/boot";
import { Studio } from "@/components/mesa/studio";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <BootScreen />;
  if (!user) return <Navigate to="/login" />;
  return <Studio />;
}
