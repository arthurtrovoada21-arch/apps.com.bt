export function BootScreen() {
  return (
    <div className="flex h-dvh flex-col bg-bg" aria-busy="true" aria-live="polite">
      <div className="flex h-14 items-center border-b border-line px-6">
        <p className="font-serif text-lg font-medium">MESA</p>
      </div>
      <div className="mx-auto w-full max-w-2xl flex-1 space-y-4 px-6 py-10">
        <p className="text-sm text-muted">Abrindo a mesa…</p>
        <div className="h-28 rounded-xl bg-subtle motion-safe:animate-pulse" />
        <div className="h-28 w-4/5 rounded-xl bg-subtle motion-safe:animate-pulse" />
      </div>
    </div>
  );
}