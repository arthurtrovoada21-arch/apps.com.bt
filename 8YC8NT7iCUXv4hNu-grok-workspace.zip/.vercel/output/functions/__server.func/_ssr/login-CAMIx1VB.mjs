import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-IWHfIGH2.mjs";
import { t as AGENTS } from "./agents-C2cE-DiL.mjs";
import { t as GROK_PROVIDERS } from "./server-DxP5dDrl.mjs";
import { r as useCurrentUserState, t as BootScreen } from "./use-current-user-49SqSQe5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CAMIx1VB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BEARER_KEY = "grok-auth.bearer-token";
function captureSessionToken(response) {
	const token = response.headers.get("set-auth-token");
	if (!token || typeof window === "undefined") return;
	try {
		window.sessionStorage.setItem(BEARER_KEY, token);
	} catch {}
}
function friendlyAuth(message) {
	const text = (message ?? "").toLowerCase();
	if (text.includes("already") || text.includes("exist")) return "Já existe uma conta com esse e-mail.";
	if (text.includes("origin")) return "Não foi possível entrar deste endereço.";
	if (text.includes("short") || text.includes("at least") || text.includes("too short")) return "A senha precisa de pelo menos 8 caracteres.";
	if (text.includes("invalid") || text.includes("credential") || text.includes("password")) return "E-mail ou senha não conferem.";
	if (text.includes("popup") || text.includes("pop-up") || text.includes("blocked")) return "O navegador bloqueou a janela. Permita pop-ups e tente de novo.";
	if (!message) return "Não deu certo. Tente de novo.";
	return message.length < 160 ? message : "Não deu certo. Tente de novo.";
}
function LoginView() {
	const [mode, setMode] = (0, import_react.useState)("create");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(null);
	async function onProvider(providerId, key) {
		setError(null);
		setBusy(key);
		try {
			await signIn(providerId, { callbackURL: "/" });
		} catch (err) {
			setError(friendlyAuth(err instanceof Error ? err.message : void 0));
			setBusy(null);
		}
	}
	async function onSubmit(event) {
		event.preventDefault();
		setError(null);
		if (mode === "create" && name.trim().length < 2) {
			setError("Diga como quer ser chamado.");
			return;
		}
		if (!email.includes("@") || password.length < 8) {
			setError(password.length < 8 ? "A senha precisa de pelo menos 8 caracteres." : "Use um e-mail válido.");
			return;
		}
		setBusy("form");
		try {
			const result = mode === "create" ? await authClient.signUp.email({
				name: name.trim(),
				email: email.trim(),
				password,
				fetchOptions: { onSuccess: (ctx) => captureSessionToken(ctx.response) }
			}) : await authClient.signIn.email({
				email: email.trim(),
				password,
				fetchOptions: { onSuccess: (ctx) => captureSessionToken(ctx.response) }
			});
			if (result.error) {
				setError(friendlyAuth(result.error.message));
				setBusy(null);
				return;
			}
			await authClient.getSession();
			window.location.assign("/");
		} catch (err) {
			setError(friendlyAuth(err instanceof Error ? err.message : void 0));
			setBusy(null);
		}
	}
	const row = AGENTS.map((agent) => agent.name).join("   ·   ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh lg:grid lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col justify-between gap-10 border-b border-line px-6 py-10 lg:border-r lg:border-b-0 lg:px-12 lg:py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted",
						children: "MESA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 font-serif text-4xl leading-tight font-medium text-fg sm:text-5xl",
						children: "Cinquenta mentes. Uma conversa."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md text-base leading-normal text-muted",
						children: "Você escolhe quem senta, pede um app, um site ou um script, e a mesa devolve uma peça que dá para abrir."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-hidden text-faint lg:block",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ticker-track flex w-max gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: row
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: row
					})]
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "flex items-center px-6 py-10 lg:px-12 lg:py-14",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl font-medium",
						children: mode === "create" ? "Criar a sua mesa" : "Entrar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-normal text-muted",
						children: "Google, X, ou um cadastro daqui. Entrar com Apple não está disponível."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 space-y-3",
						children: GROK_PROVIDERS.map((provider) => {
							const key = provider.idp === "google" ? "google" : "x";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== null,
								onClick: () => onProvider(provider.providerId, key),
								className: "flex h-11 w-full items-center justify-center rounded-lg border border-line bg-elevated px-4 text-sm font-medium text-fg transition-opacity duration-150 hover:opacity-80 disabled:cursor-wait disabled:opacity-60",
								children: busy === key ? "Abrindo…" : `Continuar com ${provider.label}`
							}, provider.providerId);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-6 flex items-center gap-3 text-xs text-faint",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" }),
							"ou com e-mail",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit,
						className: "space-y-3",
						children: [
							mode === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1.5 block text-muted",
									children: "Nome"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: name,
									onChange: (event) => setName(event.target.value),
									autoComplete: "name",
									className: "h-11 w-full rounded-sm border border-line bg-bg px-3 text-fg placeholder:text-faint",
									placeholder: "Como te chamamos"
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1.5 block text-muted",
									children: "E-mail"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									value: email,
									onChange: (event) => setEmail(event.target.value),
									autoComplete: "email",
									required: true,
									className: "h-11 w-full rounded-sm border border-line bg-bg px-3 text-fg placeholder:text-faint",
									placeholder: "voce@email.com"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1.5 block text-muted",
									children: "Senha"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									value: password,
									onChange: (event) => setPassword(event.target.value),
									autoComplete: mode === "create" ? "new-password" : "current-password",
									required: true,
									minLength: 8,
									className: "h-11 w-full rounded-sm border border-line bg-bg px-3 text-fg placeholder:text-faint",
									placeholder: "Mínimo de 8 caracteres"
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "text-sm text-danger",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: busy !== null || false,
								className: "h-11 w-full rounded-sm bg-bone text-sm font-medium text-ink transition-opacity duration-150 hover:opacity-90 disabled:cursor-wait disabled:opacity-60",
								children: busy === "form" ? "Entrando…" : mode === "create" ? "Criar conta" : "Entrar com e-mail"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-6 text-sm text-muted underline-offset-4 hover:text-fg hover:underline",
						onClick: () => {
							setMode((current) => current === "create" ? "enter" : "create");
							setError(null);
						},
						children: mode === "create" ? "Já tenho conta" : "Quero criar uma conta"
					})
				]
			})
		})]
	});
}
function LoginPage() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginView, {});
}
//#endregion
export { LoginPage as component };
