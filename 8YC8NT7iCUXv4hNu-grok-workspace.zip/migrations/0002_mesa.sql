create table if not exists threads (
  id text primary key,
  user_id text not null,
  title text not null,
  intent text not null default 'conversa',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists threads_user_idx on threads (user_id, updated_at desc);

create table if not exists messages (
  id text primary key,
  thread_id text not null references threads (id) on delete cascade,
  user_id text not null,
  role text not null,
  agent_id text,
  content text not null,
  artifact text,
  ord integer not null,
  created_at timestamptz not null default now()
);

create index if not exists messages_thread_idx on messages (thread_id, ord);

create table if not exists loadouts (
  user_id text not null,
  agent_id text not null,
  primary key (user_id, agent_id)
);
