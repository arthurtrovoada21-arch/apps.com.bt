//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DdJOkwe1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: ["/assets/index-JsoLA7jv.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-JsoLA7jv.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cg01FZQ3.js",
			"/assets/client-cLw6edTc.js",
			"/assets/agents-Bo7BtBDy.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BWW9tv_5.js",
			"/assets/client-cLw6edTc.js",
			"/assets/agents-Bo7BtBDy.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
