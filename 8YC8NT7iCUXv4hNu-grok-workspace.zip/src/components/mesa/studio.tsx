import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Copy, Menu, Plus, Send, Trash2, X } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { AGENTS, AGENT_BY_ID, MAX_AT_TABLE } from "@/lib/mesa/agents";
import {
  deleteThread,
  getLoadout,
  getMessages,
  listThreads,
  sendToMesa,
  setLoadout as saveLoadout,
} from "@/lib/mesa/council";
import { CRAFT_LABEL, CRAFTS, INTENT_LABEL, INTENTS, type Artifact, type Intent, type MesaMessage, type ThreadSummary } from "@/lib/mesa/types";

const STARTERS: { intent: Intent; label: string; text: string }[] = [
  {
    intent: "site",
    label: "Site",
    text: "Um site de uma página para um ateliê de cerâmica em São Paulo. Nome: Barro Norte. Três peças, horário de visita e como encomendar.",
  },
  {
    intent: "app",
    label: "App",
    text: "Um app de lista de mercado para celular: adicionar item, marcar como comprado e agrupar por seção.",
  },
  {
    intent: "script",
    label: "Script",
    text: "Um script em Python que lê uma pasta de fotos e organiza cópias em subpastas por ano e mês, sem apagar os originais.",
  },
  {
    intent: "plano",
    label: "Plano",
    text: "Um plano de 30 dias para abrir um café de bairro com 40 lugares, orçamento enxuto e uma identidade quieta.",
  },
];

type Sheet = "threads" | "arsenal" | "piece" | null;
type RightTab = "arsenal" | "piece";

export function Studio() {
  const [threads, setThreads] = useState<ThreadSummary[]>([]);
  const [loadout, setLoadout] = useState<string[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<MesaMessage[]>([]);
  const [intent, setIntent] = useState<Intent>("site");
  const [draft, setDraft] = useState("");
  const [bootError, setBootError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [sheet, setSheet] = useState<Sheet>(null);
  const [right, setRight] = useState<RightTab>("arsenal");
  const [pinned, setPinned] = useState<Artifact | null>(null);
  const [loadingThread, setLoadingThread] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const gen = useRef(0);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([listThreads(), getLoadout()])
      .then(([nextThreads, nextLoadout]) => {
        if (cancelled) return;
        setThreads(nextThreads);
        setLoadout(nextLoadout);
        setReady(true);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        const message = err instanceof Error ? err.message : "";
        if (message === "Unauthorized") {
          window.location.assign("/login");
          return;
        }
        setBootError("Não foi possível abrir a mesa.");
        setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const latestArtifact = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i -= 1) {
      const artifact = messages[i]?.artifact;
      if (artifact) return artifact;
    }
    return null;
  }, [messages]);

  const artifact = pinned ?? latestArtifact;

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTo({ top: node.scrollHeight });
  }, [messages, sending, activeId]);

  function newChat() {
    gen.current += 1;
    setActiveId(null);
    setMessages([]);
    setPinned(null);
    setError(null);
    setSheet(null);
    setLoadingThread(false);
  }

  async function openThread(id: string) {
    const token = ++gen.current;
    setActiveId(id);
    setPinned(null);
    setError(null);
    setSheet(null);
    setLoadingThread(true);
    setMessages([]);
    try {
      const result = await getMessages({ data: { threadId: id } });
      if (gen.current !== token) return;
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setMessages(result.messages);
      const thread = threads.find((item) => item.id === id);
      if (thread) setIntent(thread.intent);
    } catch (err: unknown) {
      if (gen.current !== token) return;
      setError(err instanceof Error ? err.message : "Não abriu a conversa.");
    } finally {
      if (gen.current === token) setLoadingThread(false);
    }
  }

  async function removeThread(id: string) {
    if (confirmDelete !== id) {
      setConfirmDelete(id);
      return;
    }
    setConfirmDelete(null);
    await deleteThread({ data: { threadId: id } });
    setThreads((prev) => prev.filter((thread) => thread.id !== id));
    if (activeId === id) newChat();
  }

  async function toggleAgent(id: string) {
    const has = loadout.includes(id);
    if (has && loadout.length === 1) {
      setNotice("A mesa precisa de pelo menos uma voz.");
      return;
    }
    if (!has && loadout.length >= MAX_AT_TABLE) {
      setNotice("Oito vozes no máximo. Tire uma para sentar outra.");
      return;
    }
    const next = has ? loadout.filter((item) => item !== id) : [...loadout, id];
    const previous = loadout;
    setLoadout(next);
    setNotice(null);
    try {
      const saved = await saveLoadout({ data: { agentIds: next } });
      setLoadout(saved);
    } catch {
      setLoadout(previous);
      setNotice("Não consegui guardar o time.");
    }
  }

  async function onSend() {
    const text = draft.trim();
    if (!text || sending) return;
    if (loadout.length === 0) {
      setError("Escolha pelo menos uma voz.");
      setSheet("arsenal");
      return;
    }
    const token = gen.current;
    const threadId = activeId;
    setSending(true);
    setError(null);
    try {
      const result = await sendToMesa({
        data: { threadId, text, intent, agentIds: loadout },
      });
      if (gen.current !== token) return;
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setDraft("");
      setActiveId(result.thread.id);
      setThreads((prev) => [result.thread, ...prev.filter((thread) => thread.id !== result.thread.id)]);
      setMessages((prev) => (threadId ? [...prev, ...result.messages] : result.messages));
      const made = [...result.messages].reverse().find((message) => message.artifact)?.artifact ?? null;
      if (made) {
        setPinned(null);
        setRight("piece");
      }
    } catch (err: unknown) {
      if (gen.current !== token) return;
      const message = err instanceof Error ? err.message : "";
      if (message === "Unauthorized") {
        window.location.assign("/login");
        return;
      }
      setError("A mesa não respondeu. O pedido continua aqui.");
    } finally {
      if (gen.current === token) setSending(false);
    }
  }

  const seated = loadout.map((id) => AGENT_BY_ID.get(id)?.name).filter(Boolean).join(", ");

  if (!ready) {
    return (
      <div className="flex h-dvh items-center justify-center bg-bg text-sm text-muted" aria-busy="true">
        Abrindo a mesa…
      </div>
    );
  }

  return (
    <div className="flex h-dvh flex-col bg-bg">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-3 sm:px-4">
        <button
          type="button"
          className="grid size-11 place-items-center rounded-sm text-fg xl:hidden"
          onClick={() => setSheet("threads")}
          aria-label="Conversas"
        >
          <Menu className="size-5" />
        </button>
        <p className="font-serif text-lg font-medium tracking-tight">MESA</p>
        <button
          type="button"
          className="hidden h-11 items-center rounded-sm px-3 text-sm text-muted hover:text-fg sm:inline-flex"
          onClick={() => {
            setRight("arsenal");
            setSheet("arsenal");
          }}
        >
          <span className="tabular-nums">{loadout.length}</span>
          <span className="ml-1">na mesa</span>
        </button>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-sm text-fg sm:hidden"
          onClick={() => {
            setRight("arsenal");
            setSheet("arsenal");
          }}
          aria-label="Arsenal"
        >
          <span className="text-sm tabular-nums">{loadout.length}</span>
        </button>
        {artifact ? (
          <button
            type="button"
            className="h-11 rounded-sm px-3 text-sm text-fg xl:hidden"
            onClick={() => setSheet("piece")}
          >
            Peça
          </button>
        ) : null}
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={newChat}
            className="inline-flex h-11 items-center gap-1 rounded-sm bg-bone px-3 text-sm font-medium text-ink"
          >
            <Plus className="size-4" />
            <span className="hidden sm:inline">Nova</span>
          </button>
          <div className="max-w-36 overflow-hidden sm:max-w-56">
            <UserButton />
          </div>
        </div>
      </header>

      {bootError ? (
        <p role="alert" className="border-b border-line px-4 py-3 text-sm text-danger">
          {bootError}
        </p>
      ) : null}

      <div className="flex min-h-0 flex-1">
        <aside className="hidden w-64 shrink-0 flex-col border-r border-line xl:flex">
          <ThreadList
            threads={threads}
            activeId={activeId}
            confirmDelete={confirmDelete}
            onOpen={(id) => void openThread(id)}
            onDelete={(id) => void removeThread(id)}
          />
        </aside>

        <section className="flex min-w-0 flex-1 flex-col">
          <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto">
            <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 py-8">
              {messages.length === 0 && !loadingThread ? (
                <EmptyState
                  seated={seated}
                  onPick={(nextIntent, text) => {
                    setIntent(nextIntent);
                    setDraft(text);
                  }}
                />
              ) : null}
              {loadingThread ? <p className="text-sm text-muted">Abrindo a conversa…</p> : null}
              {messages.map((message) => (
                <MessageBlock
                  key={message.id}
                  message={message}
                  onOpenPiece={(next) => {
                    setPinned(next);
                    setRight("piece");
                    setSheet("piece");
                  }}
                />
              ))}
              {sending ? (
                <p className="shimmer text-sm">
                  {seated.split(", ").slice(0, 3).join(", ")} {loadout.length > 3 ? "e o resto da mesa" : ""} estão
                  conversando.
                </p>
              ) : null}
            </div>
          </div>

          <Composer
            draft={draft}
            intent={intent}
            sending={sending}
            error={error}
            onDraft={setDraft}
            onIntent={setIntent}
            onSend={() => void onSend()}
          />
        </section>

        <aside className="hidden w-96 shrink-0 flex-col border-l border-line xl:flex">
          <RightPanel
            tab={right}
            onTab={setRight}
            loadout={loadout}
            notice={notice}
            artifact={artifact}
            onToggle={(id) => void toggleAgent(id)}
          />
        </aside>
      </div>

      <MobileSheet open={sheet === "threads"} title="Conversas" onClose={() => setSheet(null)}>
        <ThreadList
          threads={threads}
          activeId={activeId}
          confirmDelete={confirmDelete}
          onOpen={(id) => void openThread(id)}
          onDelete={(id) => void removeThread(id)}
        />
      </MobileSheet>
      <MobileSheet open={sheet === "arsenal"} title="Arsenal" onClose={() => setSheet(null)}>
        <Arsenal loadout={loadout} notice={notice} onToggle={(id) => void toggleAgent(id)} />
      </MobileSheet>
      <MobileSheet open={sheet === "piece"} title={artifact?.title ?? "Peça"} onClose={() => setSheet(null)}>
        <ArtifactView artifact={artifact} />
      </MobileSheet>
    </div>
  );
}

function EmptyState({
  seated,
  onPick,
}: {
  seated: string;
  onPick: (intent: Intent, text: string) => void;
}) {
  return (
    <div className="rise">
      <h1 className="font-serif text-3xl font-medium sm:text-4xl">O que a mesa constrói?</h1>
      <p className="mt-3 max-w-lg text-sm leading-normal text-muted">
        Na mesa agora: {seated || "ninguém"}. Até oito vozes por pedido. O Grok conduz, no caráter de quem você sentou.
      </p>
      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {STARTERS.map((starter) => (
          <button
            key={starter.label}
            type="button"
            onClick={() => onPick(starter.intent, starter.text)}
            className="rounded-xl border border-line bg-elevated p-4 text-left transition-colors duration-150 hover:bg-subtle"
          >
            <span className="text-xs font-medium tracking-wide text-faint">{starter.label}</span>
            <span className="mt-2 block text-sm leading-normal text-fg">{starter.text}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function MessageBlock({
  message,
  onOpenPiece,
}: {
  message: MesaMessage;
  onOpenPiece: (artifact: Artifact) => void;
}) {
  if (message.role === "user") {
    return (
      <div className="rise flex justify-end">
        <p className="max-w-[85%] rounded-lg bg-bone px-4 py-3 text-sm leading-normal text-ink">{message.content}</p>
      </div>
    );
  }
  if (message.role === "synthesis") {
    return (
      <aside className="rise rounded-xl border border-line bg-elevated p-4">
        <p className="text-xs font-medium tracking-wide text-muted">Decisão da mesa</p>
        <p className="mt-2 text-sm leading-normal whitespace-pre-wrap">{message.content}</p>
        {message.artifact ? (
          <button
            type="button"
            onClick={() => {
              if (message.artifact) onOpenPiece(message.artifact);
            }}
            className="mt-4 h-11 rounded-sm border border-line px-3 text-sm font-medium"
          >
            Abrir peça · {message.artifact.title}
          </button>
        ) : null}
      </aside>
    );
  }
  const agent = message.agentId ? AGENT_BY_ID.get(message.agentId) : undefined;
  return (
    <article className="rise flex gap-3">
      <div className="grid size-8 shrink-0 place-items-center rounded-sm bg-subtle text-xs font-medium">
        {agent?.mark ?? "MS"}
      </div>
      <div className="min-w-0">
        <header className="mb-1 flex items-baseline gap-2">
          <h3 className="text-sm font-medium">{agent?.name ?? "Mesa"}</h3>
          <p className="text-xs text-faint">{agent ? CRAFT_LABEL[agent.craft] : ""}</p>
        </header>
        <p className="text-sm leading-normal whitespace-pre-wrap">{message.content}</p>
      </div>
    </article>
  );
}

function Composer({
  draft,
  intent,
  sending,
  error,
  onDraft,
  onIntent,
  onSend,
}: {
  draft: string;
  intent: Intent;
  sending: boolean;
  error: string | null;
  onDraft: (value: string) => void;
  onIntent: (intent: Intent) => void;
  onSend: () => void;
}) {
  return (
    <div className="shrink-0 border-t border-line px-3 py-3 sm:px-4">
      <div className="mx-auto w-full max-w-2xl">
        {error ? (
          <p role="alert" className="mb-2 text-sm text-danger">
            {error}
          </p>
        ) : null}
        <div className="rounded-xl border border-line bg-elevated p-4">
          <div className="flex gap-2 overflow-x-auto pb-3">
            {INTENTS.map((item) => {
              const selected = item === intent;
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => onIntent(item)}
                  className={
                    selected
                      ? "h-11 shrink-0 rounded-sm bg-bone px-3 text-sm font-medium text-ink"
                      : "h-11 shrink-0 rounded-sm border border-line px-3 text-sm text-muted"
                  }
                >
                  {INTENT_LABEL[item]}
                </button>
              );
            })}
          </div>
          <textarea
            value={draft}
            onChange={(event) => onDraft(event.target.value)}
            onKeyDown={(event) => {
              if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
                event.preventDefault();
                onSend();
              }
            }}
            rows={3}
            maxLength={4000}
            placeholder="Peça um app, um site, um script, um texto…"
            className="w-full resize-none rounded-sm bg-transparent text-sm leading-normal text-fg placeholder:text-faint"
          />
          <div className="mt-2 flex items-center justify-between gap-3">
            <p className="text-xs text-faint">Ctrl + Enter envia</p>
            <button
              type="button"
              onClick={onSend}
              disabled={sending || draft.trim().length === 0}
              className="inline-flex h-11 items-center gap-2 rounded-sm bg-bone px-4 text-sm font-medium text-ink disabled:cursor-wait disabled:opacity-50"
            >
              <Send className="size-4" />
              {sending ? "Em conversa" : "Pedir"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ThreadList({
  threads,
  activeId,
  confirmDelete,
  onOpen,
  onDelete,
}: {
  threads: ThreadSummary[];
  activeId: string | null;
  confirmDelete: string | null;
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  if (threads.length === 0) {
    return <p className="px-4 py-6 text-sm text-muted">Nenhuma conversa ainda.</p>;
  }
  return (
    <ul className="min-h-0 flex-1 overflow-y-auto">
      {threads.map((thread) => {
        const active = thread.id === activeId;
        const when = safeWhen(thread.updatedAt);
        return (
          <li key={thread.id} className={active ? "bg-subtle" : undefined}>
            <div className="flex items-start gap-1 px-2 py-1">
              <button type="button" onClick={() => onOpen(thread.id)} className="min-h-11 min-w-0 flex-1 px-2 py-2 text-left">
                <span className="block truncate text-sm font-medium">{thread.title}</span>
                <span className="mt-0.5 block text-xs text-faint">
                  {INTENT_LABEL[thread.intent]}
                  {when ? ` · ${when}` : ""}
                </span>
              </button>
              <button
                type="button"
                onClick={() => onDelete(thread.id)}
                className="mt-2 grid size-11 shrink-0 place-items-center rounded-sm text-faint hover:text-fg"
                aria-label={confirmDelete === thread.id ? "Confirmar apagar" : "Apagar conversa"}
              >
                {confirmDelete === thread.id ? <span className="text-xs text-danger">Sim</span> : <Trash2 className="size-4" />}
              </button>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function safeWhen(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return formatDistanceToNow(date, { addSuffix: true, locale: ptBR });
}

function RightPanel({
  tab,
  onTab,
  loadout,
  notice,
  artifact,
  onToggle,
}: {
  tab: RightTab;
  onTab: (tab: RightTab) => void;
  loadout: string[];
  notice: string | null;
  artifact: Artifact | null;
  onToggle: (id: string) => void;
}) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex gap-2 border-b border-line p-3">
        <TabButton selected={tab === "arsenal"} onClick={() => onTab("arsenal")}>
          Arsenal
        </TabButton>
        <TabButton selected={tab === "piece"} onClick={() => onTab("piece")}>
          Peça
        </TabButton>
      </div>
      {tab === "arsenal" ? <Arsenal loadout={loadout} notice={notice} onToggle={onToggle} /> : <ArtifactView artifact={artifact} />}
    </div>
  );
}

function TabButton({
  selected,
  onClick,
  children,
}: {
  selected: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        selected
          ? "h-11 flex-1 rounded-sm bg-bone text-sm font-medium text-ink"
          : "h-11 flex-1 rounded-sm border border-line text-sm text-muted"
      }
    >
      {children}
    </button>
  );
}

function Arsenal({
  loadout,
  notice,
  onToggle,
}: {
  loadout: string[];
  notice: string | null;
  onToggle: (id: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [craft, setCraft] = useState<(typeof CRAFTS)[number] | "todas">("todas");
  const needle = query.trim().toLowerCase();
  const visible = AGENTS.filter((agent) => {
    if (craft !== "todas" && agent.craft !== craft) return false;
    if (!needle) return true;
    return `${agent.name} ${agent.line}`.toLowerCase().includes(needle);
  });

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="space-y-3 border-b border-line px-4 py-4">
        <p className="text-sm leading-normal text-muted">
          {AGENTS.length} vozes. Até {MAX_AT_TABLE} sentam. O Grok conduz no caráter de quem você escolhe — não há conta
          separada de cada uma.
        </p>
        <p className="text-xs text-faint tabular-nums">
          {loadout.length} de {MAX_AT_TABLE} na mesa
        </p>
        {notice ? <p className="text-sm text-danger">{notice}</p> : null}
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Buscar voz"
          className="h-11 w-full rounded-sm border border-line bg-bg px-3 text-sm placeholder:text-faint"
        />
        <div className="flex gap-2 overflow-x-auto">
          <FilterChip selected={craft === "todas"} onClick={() => setCraft("todas")}>
            Todas
          </FilterChip>
          {CRAFTS.map((item) => (
            <FilterChip key={item} selected={craft === item} onClick={() => setCraft(item)}>
              {CRAFT_LABEL[item]}
            </FilterChip>
          ))}
        </div>
      </div>
      <ul className="min-h-0 flex-1 overflow-y-auto">
        {visible.map((agent) => {
          const on = loadout.includes(agent.id);
          return (
            <li key={agent.id} className="border-b border-line">
              <button
                type="button"
                onClick={() => onToggle(agent.id)}
                className="flex min-h-11 w-full items-center gap-3 px-4 py-3 text-left"
                aria-pressed={on}
              >
                <span className="grid size-8 shrink-0 place-items-center rounded-sm bg-subtle text-xs font-medium">
                  {agent.mark}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-medium">{agent.name}</span>
                  <span className="block truncate text-xs text-faint">
                    {CRAFT_LABEL[agent.craft]} · {agent.line}
                  </span>
                </span>
                <span className={on ? "text-xs font-medium text-fg" : "text-xs text-faint"}>{on ? "Na mesa" : "Sentar"}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function FilterChip({
  selected,
  onClick,
  children,
}: {
  selected: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        selected
          ? "h-11 shrink-0 rounded-sm bg-subtle px-3 text-sm text-fg"
          : "h-11 shrink-0 rounded-sm px-3 text-sm text-faint"
      }
    >
      {children}
    </button>
  );
}

function ArtifactView({ artifact }: { artifact: Artifact | null }) {
  const [copied, setCopied] = useState(false);
  const [frame, setFrame] = useState<"full" | "phone">("full");
  if (!artifact) {
    return (
      <div className="px-4 py-8">
        <p className="font-serif text-2xl font-medium">Ainda sem peça</p>
        <p className="mt-2 text-sm leading-normal text-muted">
          Peça um site, um app ou um script. A entrega aparece aqui, com prévia quando for uma página.
        </p>
      </div>
    );
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(artifact?.content ?? "");
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  function download() {
    const blob = new Blob([artifact?.content ?? ""], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const ext = artifact?.kind === "html" ? "html" : artifact?.kind === "markdown" ? "md" : "txt";
    link.href = url;
    link.download = `${slug(artifact?.title ?? "peca")}.${ext}`;
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-2 border-b border-line px-3 py-2">
        <p className="min-w-0 flex-1 truncate text-sm font-medium">{artifact.title}</p>
        {copied ? <span className="text-xs text-muted">Copiado</span> : null}
        {artifact.kind === "html" ? (
          <button
            type="button"
            onClick={() => setFrame((current) => (current === "full" ? "phone" : "full"))}
            className="h-11 rounded-sm px-2 text-xs text-muted"
          >
            {frame === "full" ? "Celular" : "Largo"}
          </button>
        ) : null}
        <button type="button" onClick={() => void copy()} className="grid size-11 place-items-center rounded-sm" aria-label={copied ? "Copiado" : "Copiar"}>
          <Copy className="size-4" />
        </button>
        <button type="button" onClick={download} className="h-11 rounded-sm px-2 text-xs text-muted">
          Baixar
        </button>
      </div>
      {artifact.kind === "html" ? (
        <div className={frame === "phone" ? "mx-auto min-h-0 w-full max-w-sm flex-1 p-3" : "min-h-0 flex-1"}>
          <iframe
            title={artifact.title}
            sandbox="allow-scripts"
            srcDoc={artifact.content}
            className="h-full min-h-80 w-full bg-bone"
          />
        </div>
      ) : (
        <pre className="min-h-0 flex-1 overflow-auto px-4 py-4 font-mono text-xs leading-normal whitespace-pre-wrap text-fg">
          {artifact.content}
        </pre>
      )}
    </div>
  );
}

function slug(value: string): string {
  const clean = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return clean || "peca";
}

function MobileSheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-30 flex flex-col bg-bg xl:hidden">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-2">
        <button type="button" onClick={onClose} className="grid size-11 place-items-center rounded-sm" aria-label="Fechar">
          <X className="size-5" />
        </button>
        <h2 className="truncate text-sm font-medium">{title}</h2>
      </header>
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden">{children}</div>
    </div>
  );
}
