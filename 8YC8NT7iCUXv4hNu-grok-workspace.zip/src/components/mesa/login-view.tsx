import { useState, type FormEvent } from "react";
import { authClient, authEnabled, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { AGENTS } from "@/lib/mesa/agents";

const BEARER_KEY = "grok-auth.bearer-token";

function captureSessionToken(response: { headers: { get(name: string): string | null } }) {
  const token = response.headers.get("set-auth-token");
  if (!token || typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(BEARER_KEY, token);
  } catch {
    /* preview storage can be blocked; cookie auth still works when deployed */
  }
}

function friendlyAuth(message: string | undefined): string {
  const text = (message ?? "").toLowerCase();
  if (text.includes("already") || text.includes("exist")) return "Já existe uma conta com esse e-mail.";
  if (text.includes("origin")) return "Não foi possível entrar deste endereço.";
  if (text.includes("short") || text.includes("at least") || text.includes("too short")) {
    return "A senha precisa de pelo menos 8 caracteres.";
  }
  if (text.includes("invalid") || text.includes("credential") || text.includes("password")) {
    return "E-mail ou senha não conferem.";
  }
  if (text.includes("popup") || text.includes("pop-up") || text.includes("blocked")) {
    return "O navegador bloqueou a janela. Permita pop-ups e tente de novo.";
  }
  if (!message) return "Não deu certo. Tente de novo.";
  return message.length < 160 ? message : "Não deu certo. Tente de novo.";
}

export function LoginView() {
  const [mode, setMode] = useState<"enter" | "create">("create");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<"google" | "x" | "form" | null>(null);

  async function onProvider(providerId: string, key: "google" | "x") {
    setError(null);
    setBusy(key);
    try {
      await signIn(providerId, { callbackURL: "/" });
    } catch (err) {
      setError(friendlyAuth(err instanceof Error ? err.message : undefined));
      setBusy(null);
    }
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (mode === "create" && name.trim().length < 2) {
      setError("Diga como quer ser chamado.");
      return;
    }
    if (!email.includes("@") || password.length < 8) {
      setError(password.length < 8 ? "A senha precisa de pelo menos 8 caracteres." : "Use um e-mail válido.");
      return;
    }
    setBusy("form");
    try {
      const result =
        mode === "create"
          ? await authClient.signUp.email({
              name: name.trim(),
              email: email.trim(),
              password,
              fetchOptions: { onSuccess: (ctx) => captureSessionToken(ctx.response) },
            })
          : await authClient.signIn.email({
              email: email.trim(),
              password,
              fetchOptions: { onSuccess: (ctx) => captureSessionToken(ctx.response) },
            });
      if (result.error) {
        setError(friendlyAuth(result.error.message));
        setBusy(null);
        return;
      }
      await authClient.getSession();
      window.location.assign("/");
    } catch (err) {
      setError(friendlyAuth(err instanceof Error ? err.message : undefined));
      setBusy(null);
    }
  }

  const row = AGENTS.map((agent) => agent.name).join("   ·   ");

  return (
    <main className="min-h-dvh lg:grid lg:grid-cols-2">
      <section className="flex flex-col justify-between gap-10 border-b border-line px-6 py-10 lg:border-r lg:border-b-0 lg:px-12 lg:py-14">
        <div className="max-w-xl">
          <p className="text-sm font-medium tracking-wide text-muted">MESA</p>
          <h1 className="mt-6 font-serif text-4xl leading-tight font-medium text-fg sm:text-5xl">
            Cinquenta mentes. Uma conversa.
          </h1>
          <p className="mt-5 max-w-md text-base leading-normal text-muted">
            Você escolhe quem senta, pede um app, um site ou um script, e a mesa devolve uma peça que dá para abrir.
          </p>
        </div>
        <div className="hidden overflow-hidden text-faint lg:block" aria-hidden="true">
          <div className="ticker-track flex w-max gap-8">
            <p className="text-sm">{row}</p>
            <p className="text-sm">{row}</p>
          </div>
        </div>
      </section>

      <section className="flex items-center px-6 py-10 lg:px-12 lg:py-14">
        <div className="w-full max-w-md">
          <h2 className="font-serif text-3xl font-medium">{mode === "create" ? "Criar a sua mesa" : "Entrar"}</h2>
          <p className="mt-3 text-sm leading-normal text-muted">
            Google, X, ou um cadastro daqui. Entrar com Apple não está disponível.
          </p>

          {authEnabled ? (
            <div className="mt-8 space-y-3">
              {GROK_PROVIDERS.map((provider) => {
                const key = provider.idp === "google" ? "google" : "x";
                return (
                  <button
                    key={provider.providerId}
                    type="button"
                    disabled={busy !== null}
                    onClick={() => onProvider(provider.providerId, key)}
                    className="flex h-11 w-full items-center justify-center rounded-lg border border-line bg-elevated px-4 text-sm font-medium text-fg transition-opacity duration-150 hover:opacity-80 disabled:cursor-wait disabled:opacity-60"
                  >
                    {busy === key ? "Abrindo…" : `Continuar com ${provider.label}`}
                  </button>
                );
              })}
            </div>
          ) : (
            <p className="mt-8 text-sm text-muted">O acesso está desligado.</p>
          )}

          <div className="my-6 flex items-center gap-3 text-xs text-faint">
            <span className="h-px flex-1 bg-line" />
            ou com e-mail
            <span className="h-px flex-1 bg-line" />
          </div>

          <form onSubmit={onSubmit} className="space-y-3">
            {mode === "create" ? (
              <label className="block text-sm">
                <span className="mb-1.5 block text-muted">Nome</span>
                <input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  autoComplete="name"
                  className="h-11 w-full rounded-sm border border-line bg-bg px-3 text-fg placeholder:text-faint"
                  placeholder="Como te chamamos"
                />
              </label>
            ) : null}
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">E-mail</span>
              <input
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                autoComplete="email"
                required
                className="h-11 w-full rounded-sm border border-line bg-bg px-3 text-fg placeholder:text-faint"
                placeholder="voce@email.com"
              />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Senha</span>
              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete={mode === "create" ? "new-password" : "current-password"}
                required
                minLength={8}
                className="h-11 w-full rounded-sm border border-line bg-bg px-3 text-fg placeholder:text-faint"
                placeholder="Mínimo de 8 caracteres"
              />
            </label>
            {error ? (
              <p role="alert" className="text-sm text-danger">
                {error}
              </p>
            ) : null}
            <button
              type="submit"
              disabled={busy !== null || !authEnabled}
              className="h-11 w-full rounded-sm bg-bone text-sm font-medium text-ink transition-opacity duration-150 hover:opacity-90 disabled:cursor-wait disabled:opacity-60"
            >
              {busy === "form" ? "Entrando…" : mode === "create" ? "Criar conta" : "Entrar com e-mail"}
            </button>
          </form>

          <button
            type="button"
            className="mt-6 text-sm text-muted underline-offset-4 hover:text-fg hover:underline"
            onClick={() => {
              setMode((current) => (current === "create" ? "enter" : "create"));
              setError(null);
            }}
          >
            {mode === "create" ? "Já tenho conta" : "Quero criar uma conta"}
          </button>
        </div>
      </section>
    </main>
  );
}
